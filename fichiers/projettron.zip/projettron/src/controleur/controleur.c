#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ncurses.h>
#include <math.h>

#include "controleur.h"



// gère les inputs du joueur pour le déplacer en adéquation
// utilisation de nodelay pour le déplacment automatique

enum moving_position get_input(enum moving_position last_pos){
	nodelay(stdscr, TRUE); 
    char input = getch();  
    nodelay(stdscr, FALSE);
	
	int temp;
	switch(input){
		case 'q': temp = -1;break;
		case 'd': temp = 1;break;
		default:return -1;
	}
    int nouv = (last_pos +temp);
	if (nouv<0)nouv = 3;
	else nouv = nouv%4;
	return (enum moving_position)nouv;
}
enum moving_position get_input_p2(enum moving_position last_pos) {
    nodelay(stdscr, TRUE);
    int input = getch();
    nodelay(stdscr, FALSE);

    int temp = 0;
    switch (input) {
        case KEY_LEFT:temp = -1;break;
        case KEY_RIGHT:temp = 1;break;
        default:return -1;
    }

    int nouv = (last_pos + temp);
    if (nouv < 0)nouv = 3; 
    else nouv = nouv % 4; 
    return (enum moving_position)nouv;
}
// enum moving_position get_input(enum moving_position last_pos){
// 	nodelay(stdscr, TRUE); 
//     char input = getch();  
//     nodelay(stdscr, FALSE);

// 	switch(input){
// 		case 'z': return TOP;
// 		case 's': return BOT;
// 		case 'q': return LEFT;
// 		case 'd': return RIGHT;
// 		default:return -1;
// 	}
// }

//récupère les inputsdu joueur 1 avec les inputs q et d pour les déplacements
enum moving_position get_input_sdl(SDL_Event *event,enum moving_position last_pos) {
	int temp;
    if (event->type == SDL_KEYDOWN) {
        switch (event->key.keysym.sym) {
            case SDLK_q:
                temp = -1;
				break;
            case SDLK_d:
                temp = 1;
				break;
            default:
                return -1;
        }
    }
    int nouv = (last_pos +temp);
	if (nouv<0)nouv = 3;
	else nouv = nouv%4;
	return (enum moving_position)nouv;
}
//récupère les inputs du joueur 2 avec les inputs flèches gauche et droite pour les déplacements
enum moving_position get_input_sdl_p2(SDL_Event *event, enum moving_position last_pos) {
    int temp = 0;

    if (event->type == SDL_KEYDOWN) {
        switch (event->key.keysym.sym) {
            case SDLK_LEFT:
                temp = -1;
                break;
            case SDLK_RIGHT:
                temp = 1;
                break;
            default:
                return last_pos; // Aucun changement si une autre touche est pressée
        }
    }

    int nouv = last_pos + temp;
    if (nouv < 0) {
        nouv = 3; // Retourne à la dernière position si en dessous de 0
    } else {
        nouv = nouv % 4; // Limite le cycle à 4 positions
    }

    return (enum moving_position)nouv;
}
// enum moving_position get_input_sdl(SDL_Event *event) {
//     if (event->type == SDL_KEYDOWN) {
//         switch (event->key.keysym.sym) {
//             case SDLK_z:
//                 return TOP;
//             case SDLK_s:
//                 return BOT;
//             case SDLK_q:
//                 return LEFT;
//             case SDLK_d:
//                 return RIGHT;
//             default:
//                 return -1;
//         }
//     }
//     return -1;
// }

//Gère les déplacements du joueur
//vérifie si une collision à lieu ou non
int move_play(player *p1, enum moving_position pos, int **mat) {
    switch (pos) {
        case LEFT: 
            if (!collision(p1->x, p1->y - 1, mat))
                move_left(p1, mat);
			else goto end;
			break;
        case RIGHT: 
            if (!collision(p1->x, p1->y + 1, mat))
                move_right(p1, mat);
            else goto end;
			break;
        case TOP: 
            if (!collision(p1->x - 1, p1->y, mat))
                move_top(p1, mat);
            else goto end;
			break;
        case BOT: 
            if (!collision(p1->x + 1, p1->y, mat))
                move_bot(p1, mat);
            else goto end;
			break;
    }
	return 0;
	end :
		return 1;
}
//Gère les déplacement de l'ia en utilisant la structure du joueur
//on lui donne également la matrice en paramètre pour mettre à jour ses propres coordonnées
int move_ai(player *p2,enum moving_position last_pos,int **mat){
	switch(last_pos){
		case LEFT: 
            if (!collision(p2->x, p2->y - 1, mat)){
                move_left(p2, mat);
				break;
			}
			else {
				if(other_move_ai(p2,mat))
				break;
				else return 0;
			}
        case RIGHT: 
            if (!collision(p2->x, p2->y + 1, mat)){
                move_right(p2, mat);
            	break;
			}
			else {
				if(other_move_ai(p2,mat))
				break;
				else return 0;
			}
        case TOP: 
            if (!collision(p2->x - 1, p2->y, mat)){
                move_top(p2, mat);
            	break;
			}
			else {
				if(other_move_ai(p2,mat))
				break;
				else return 0;
			}
        case BOT: 
            if (!collision(p2->x + 1, p2->y, mat)){
                move_bot(p2, mat);
				break;
			}
			else {
				if (other_move_ai(p2,mat))
				break;
				else return 0;
			}
	}
	return 1;

}
//déplace à un endroit qui ne tue pas l'ia si possible 
int other_move_ai(player *p2,int**mat){
	if (!collision(p2->x, p2->y - 1, mat)){move_left(p2, mat);return 1;}
	else if (!collision(p2->x+1, p2->y, mat)){move_bot(p2, mat);return 1;}
	else if (!collision(p2->x - 1, p2->y, mat)){move_top(p2, mat);return 1;}
	else if (!collision(p2->x, p2->y+1, mat)){move_right(p2, mat);return 1;}
	else {move_right(p2,mat);return 0;}
}
//déplacement vers le haut
void move_top(player *p1,int **mat){
	actualisation(p1,p1->x-1,p1->y,mat);
}
//déplacement vers la droite
void move_right(player *p1,int **mat){
	actualisation(p1,p1->x,p1->y+1,mat);
}
//déplacement vers la gauche
void move_left(player *p1,int **mat){
	actualisation(p1,p1->x,p1->y-1,mat);
}
//déplacement vers le bas
void move_bot(player *p1,int **mat){
	actualisation(p1,p1->x+1,p1->y,mat);
}

//gère la boucle des jeu des déplacements
int gameplay_loop(int **matrice,player *p1,player *p2,enum moving_position last_pos_ia,enum moving_position last_pos,int choice){
	if (choice != 3){
		if (!move_ai(p2,last_pos_ia,matrice)){
			return 2;
		}
	}
	else {
		if (move_play(p2,last_pos_ia, matrice))return 2;
	}
	//oui c'est pas logique entre !move_ai et move_play
	if (move_play(p1,last_pos, matrice)) {
		return 1;
	}
	return -1;
}
//réinitialise certaines valeurs qui ont souvent besoin d'être modifiés
void reinit_val(int ** matrice,player *p1,player *p2,enum moving_position *last_pos,enum moving_position *last_pos_ia){
	matrice = init_tab();
	player np1 = {2, 2, 'j'}; 
	player np2 = {6,6, 'i'}; 
	p1 = &np1;p2=&np2;
	enum moving_position nlast_pos = RIGHT;last_pos = &nlast_pos;
	enum moving_position nlast_pos_ia = RIGHT;last_pos_ia = &nlast_pos_ia;
}
//nettoie ncurses
void clear_ncurses(int **matrice){
	nettoyage(matrice);
	endwin();
}
//fonction pas encore finie qui prévoie d'améliorer l'ia du jeu
void update_ia(int **matrice,player *p1,enum moving_position last_pos_ia){
	//int coordx = p1->x;
	//int coordy = p1->y;

}
//prototype upgrade ia
// //je crois qu'il y a eu un probleme avec les x et y en cours de route mais c'est pas grave
// //le but est de trouver quel est la direction actuelle de l'ia puis de trouver si le chemin qui va être pris sépare la carte en 2 chemins différents
// //puis de prendre le chemin avec le plus de place
// int find_maxplace(int **mat,int x,int y,enum moving_position last_pos_ia){
// 	int un = 0;
// 	int deux = 0;
// 	switch(last_pos_ia){
// 		case LEFT: 
//             if (!collision(x,y - 1, mat)){
//                 un = calc_max(mat,x,y-1,TOP);
// 				deux = calc_max(mat,x,y-1,BOT);
// 				break;
// 			}
//         case RIGHT: 
//             if (!collision(x,y + 1, mat)){
//                 un  = calc_max(mat,x,y+1,TOP);
// 				deux  = calc_max(mat,x,y+1,BOT);
//             	break;
// 			}
//         case TOP: 
//             if (!collision(x - 1,y, mat)){
//                 un = calc_max(mat,x-1,y,LEFT);
// 				deux = calc_max(mat,x-1,y,RIGHT);
//             	break;
// 			}
//         case BOT: 
//             if (!collision(x + 1,y, mat)){
//                 un = calc_max(mat,x+1,y,LEFT);
// 				deux = calc_max(mat,x+1,y,RIGHT);
// 				break;
// 			}
// 	}
// 	return max(un,deux);
// }
// //calcul la surface la plus grande depuis le chemin du prochain déplacement
// int calc_max(int ** mat,int x, int y,enum moving_position last){
// 	//mat[x][y]=2;
// 	int **copie = mat;
// 	parcour(mat,x,y,copie);
// }
// int parcour(int ** mat,int x,int y,int **parcour){
// 	//rappel récursif pour chaque direction qui n'est pas == 0 dans parcour puis mettre une val dedans
// }