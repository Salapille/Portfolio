#pragma once
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ncurses.h>
#include "ncurses.h"
#include "../modele/modele.h"

enum moving_position {TOP=0,BOT=2,RIGHT=1,LEFT=3};
enum moving_position get_input(enum moving_position last_pos);

enum moving_position get_input_sdl(SDL_Event *event,enum moving_position last_pos);
int move_play(player *p1,enum moving_position pos,int**mat);
int move_ai(player *p2,enum moving_position last_pos,int **mat);
int other_move_ai(player *p2,int**mat);
void move_left(player *p1,int**mat);

void move_right(player *p1,int**mat);

void move_top(player *p1,int**mat);

void move_bot(player *p1,int**mat);

int gameplay_loop(int **matrice,player *p1,player *p2,enum moving_position last_pos_ia,enum moving_position last_pos,int choice);

void reinit_val(int ** matrice,player *p1,player *p2,enum moving_position *last_pos,enum moving_position *last_pos_ia);

void clear_ncurses(int **matrice);

enum moving_position get_input_sdl_p2(SDL_Event *event, enum moving_position last_pos);
enum moving_position get_input_p2(enum moving_position last_pos);
 