#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <unistd.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>

#include "controleur/controleur.h"
#include "modele/modele.h"
#include "vue/vue_ncurses.h"
#include "vue/vue_sdl.h"

//programme main qui permet de jouer au jeu
int main(int argc,char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s [n|s]\n", argv[0]);
        fprintf(stderr, "  n : pour utiliser ncurses\n");
        fprintf(stderr, "  make run-n : pour utiliser ncurses\n");
        fprintf(stderr, "  s : pour utiliser SDL2\n");
        fprintf(stderr, "  make run-s : pour utiliser SDL2\n");
        return 1;
    }
    init_music();
    int loop = 0;
    start:
    // Initialiser des variables communes aux deux vues
    loop++;
    int choice;
    int lives = 3;
    int lives_p2 = 3;
    int score = 0; 
    int niveau_act=0;
    int niveau = 600000;
    int **matrice;
    int retour = 0;
    matrice = init_tab();

    enum moving_position last_pos = RIGHT;
    enum moving_position last_pos_ia = RIGHT;
    //Boucle Ncurses//
    

    if (strcmp(argv[1], "n") == 0){
        init_vue_ncurses();
        choice = menu_ncurses();
        if (choice == 4){clear_ncurses(matrice);return 0;}
        if (choice == 5){init_leaderboard_ncurses();goto start;}
        if (choice == 2||choice ==3) niveau = 100000;
        if (choice !=3)lives_p2 = 1;
        start_ncurses :
            // Initialise le tableau
            
            matrice = init_tab();
            player p1 = {get_length()/4, get_width()/4, 'j'}; 
            player p2 = {get_length()/2, get_width()/2, 'i'}; 
            last_pos = RIGHT;
            last_pos_ia = RIGHT;
            // Boucle de jeu
        
            while (1) {
                // Effacer l'écran
                clear();

                // Afficher la matrice le score et le niveau
                display_ncurses(matrice,score,niveau_act,lives,lives_p2);
                //gère le déplacement de l'ia
                refresh();
                enum moving_position pos = get_input(last_pos);
                if (pos == -1) pos = last_pos; 
                else last_pos = pos;
                if (choice == 3){
                    enum moving_position pos_ia = get_input_p2(last_pos_ia);
                    if (pos_ia == -1) pos_ia = last_pos_ia; 
                    else last_pos_ia = pos_ia;
                }
                retour  = gameplay_loop(matrice,&p1,&p2,last_pos_ia,last_pos,choice);
                if (retour == 1){
                    lives --;
                    if (!loose_life(matrice,lives,argv[1])){end_screen(score,choice,lives,lives_p2,niveau_act);goto start;}
                    goto start_ncurses;
                }
                if (retour == 2){   
                    if (choice == 1){
                        mvprintw(get_length() + 2, 0, "Collision détectée ia ! Fin du jeu.");
                        niveau_act++;
                        if (niveau_act>=6){
                            niveau -= 10000;
                        }
                        else{
                            niveau -= 100000;
                        }
                    }
                    else if (choice == 3){
                        if (lives_p2<1){
                            clear();
                            end_screen(score,choice,lives,lives_p2,niveau_act);
                            clear_ncurses(matrice);
                            goto start;
                        }
                        lives_p2 --;
                        mvprintw(get_length() + 2, 0, "Collision détectée joueur2 perds une vie");
                    }
                    nettoyage(matrice);
                    refresh();
                    usleep(3000000);
                    goto start_ncurses;
                }
                score++;
                refresh();
                // permet de gérer la vitesse du jeu correspond au niveau
                usleep(niveau);  
        }
    }


    // Boucle SDL //
    else if (strcmp(argv[1], "s") == 0) {
        int running = 1;
        if (loop != 1)goto suite;
        SDL_Event event;
        
        SDL_Window *window = init_window();
        SDL_Renderer *renderer = init_renderer(window);
        TTF_Font *font =init_ttf();
        suite :
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // Noir
        SDL_RenderClear(renderer);
        choice = sdl_menu(window,renderer,font);
        if (choice == 4){destroy_sdl(window,renderer);return 0;}
        if (choice == 5){init_leaderboard_sdl(renderer,font);goto start;}
        if (choice == 2 ||choice == 3) niveau = 100000;
        if (choice !=3)lives_p2 = 1;
        start_sdl:
        matrice = init_tab();
        player p1 = {get_length()/4, get_width()/4, 'j'}; 
        player p2 = {get_length()/2, get_width()/2, 'i'}; 
        last_pos = RIGHT;
        last_pos_ia = RIGHT;
        
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // Noir
        SDL_RenderClear(renderer);

        display_loop(matrice,renderer,window,font,score,niveau_act,lives,lives_p2);
        while (running) {
            // Gérer les événements SDL quitter et les inputs
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) {
                    running = 0; 
                    return 0;
                }
                else if (event.type == SDL_KEYDOWN) {
                    enum moving_position pos = get_input_sdl(&event,last_pos);
                    if (pos != -1) {
                        last_pos = pos; 
                    }
                    if (choice == 3){
                        enum moving_position pos_ia = get_input_sdl_p2(&event,last_pos_ia);
                        if (pos_ia != -1) {
                            last_pos_ia = pos_ia; 
                        }
                    }
                }
            }
            retour  = gameplay_loop(matrice,&p1,&p2,last_pos_ia,last_pos,choice);
            if (retour == 1){
                lives --;
                display_hit(renderer,font);
                if (!loose_life(matrice,lives,argv[1])){
                    end_game_screen(renderer,font,lives,lives_p2,choice,score,niveau);
                    //ajouter au leaderboard
                    goto start;}
                goto start_sdl;
            }
            //faire avec le j2 et pas l'ia if choice == 3
            if (retour == 2){
                if (choice == 1){
                    display_lv_up(renderer,font);
                    niveau_act++;
                    if (niveau_act>=6){
                        niveau -= 10000;
                    }
                    else{
                        niveau -= 100000;
                    }
                }
                else if(choice == 3){
                    if (lives_p2<=0){end_game_screen(renderer,font,lives,lives_p2,choice,score,niveau);goto start;}
                    lives_p2--;
                    display_ia_collide(renderer,font,choice);
                }
                else display_ia_collide(renderer,font,choice);
                nettoyage(matrice);
                usleep(300000);
                goto start_sdl;
            }
            SDL_RenderPresent(renderer);
            score++;
            display_loop(matrice,renderer,window,font,score,niveau_act,lives,lives_p2);
            usleep(niveau); 
        }

        // Nettoyage SDL (uniquement après que l'utilisateur quitte)
        
        destroy_sdl(window, renderer);
    }

}
