#pragma once
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ncurses.h>

#include "../controleur/controleur.h"
#include "../modele/modele.h"
typedef struct {
    int x, y, w, h;
    const char* label;
} Button;

void setColorByValue(SDL_Renderer *renderer, int value);
void display_mat_sdl(int **mat,SDL_Renderer *renderer );
SDL_Window *init_window();
SDL_Renderer *init_renderer(SDL_Window *window);
void destroy_sdl(SDL_Window *window, SDL_Renderer *renderer);
TTF_Font *init_ttf() ;
void display_score_sdl(SDL_Renderer *renderer, TTF_Font *font, int score, int niveau);
void display_life_sdl(SDL_Renderer *renderer, TTF_Font *font, int lives,int lives_p2);
void display_text(SDL_Renderer *renderer, const char *text, int x, int y, SDL_Color color,TTF_Font *font);
int sdl_menu(SDL_Window *window,SDL_Renderer *renderer,TTF_Font *font);
void draw_button(SDL_Renderer* renderer, Button button, SDL_Color color);
bool is_inside(int mouse_x, int mouse_y, Button button);
void display_loop(int **matrice,SDL_Renderer *renderer,SDL_Window *window,TTF_Font *font,int score,int niveau_act,int lives,int lives_p2);
void display_hit(SDL_Renderer *renderer,TTF_Font *font);
void display_lv_up(SDL_Renderer *renderer,TTF_Font *font);
void display_ia_collide(SDL_Renderer *renderer,TTF_Font *font,int choice);
void end_game_screen(SDL_Renderer *renderer,TTF_Font * font,int lives,int lives_p2,int choix,int score,int niveau);
void display_leaderboard_sdl(SDL_Renderer *renderer, TTF_Font *font,ScoreThing *scores, int count);
void init_leaderboard_sdl(SDL_Renderer *renderer,TTF_Font *font);
void get_player_name_sdl(SDL_Renderer *renderer, TTF_Font *font, char *name, int max_length);