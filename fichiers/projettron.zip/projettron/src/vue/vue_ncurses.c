#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ncurses.h>
#include <unistd.h>

#include "vue_ncurses.h"
#define MAX_ENTRIES 100

//initialise les différentes couleurs pour les objets
void init_colors() {
    if (has_colors() == FALSE) {
        endwin();
        printf("Votre terminal ne supporte pas les couleurs.\n");
        exit(1);
    }
    start_color();
    init_pair(1, COLOR_RED, COLOR_BLACK);    // Couleur pour le joueur
    init_pair(2, COLOR_BLUE, COLOR_BLACK);   // Couleur pour l'IA
    init_pair(3, COLOR_WHITE, COLOR_BLACK);  // Couleur pour les cases vides
	init_pair(4, COLOR_GREEN, COLOR_BLACK);  // Couleur pour les cases de limites
}
//permet d'afficher les cases en fonctions de ce qu'il y a dans la matrice
void display_board(int **tab){

	int width = get_width();
	int length = get_length();

	for(unsigned i = 0;i<length;i++){
		for(unsigned j = 0;j<width;j++){
			int truc = tab[i][j];
				switch(truc){
					case 0: // Case vide
						attron(COLOR_PAIR(3));
						mvprintw(i, j * 2, "  "); // Rectangle vide
						attroff(COLOR_PAIR(3));
						break;
					case 1: // Joueur
						display_player(i, j);
						break;
					case 2: // IA
						display_ai(i, j);
						break;
					case 3:
						display_border(i,j);
						break;
					default:
				}
		}
	}
	refresh();
	//display_score();
}
//colori les cases du joueur 1
void display_player(int i, int j) {
    attron(COLOR_PAIR(1)); 
    mvprintw(i, j * 2, "#"); 
    attroff(COLOR_PAIR(1)); 
}
//colori les cases du jouer 2 ou de l'ia
void display_ai(int i, int j) {
    attron(COLOR_PAIR(2));  
    mvprintw(i, j * 2, "#"); 
    attroff(COLOR_PAIR(2)); 
}
//colori les bords de la carte ainsi que les obstacles
void display_border(int i,int j){
	attron(COLOR_PAIR(4));
	mvprintw(i,j*2,"#");
	attroff(COLOR_PAIR(4));
}
// affiche le score actuel ainsi que le niveau
void display_score(int score,int niveau){
	mvprintw(get_length() + 2, 0, "Score : %2.f", calc_score(score,niveau)*37.5);
	mvprintw(get_length() + 3, 0, "Niveau : %d", niveau);
}
//affichage de la vie du joueur 1
void display_life(int life){
	mvprintw(get_length() + 4, 0,"Vie j1: %d",life);
}
//affichage de la vie du joueur 2
void display_life_p2(int life_p2){
	mvprintw(get_length() + 5, 0,"Vie j2: %d",life_p2);
}
//menu des choix des modes de jeu de ncurses
int menu_ncurses(){
	int ch, x, y;
    MEVENT event;

    // Afficher un menu
	mvprintw(2, 10, "Leaderboard");
    mvprintw(3, 10, "Niveaux accelerants");
    mvprintw(4, 10, "Vitesse idéale");
    mvprintw(5, 10, "Deux joueurs");
	mvprintw(6, 10, "Quitter");

    // Rafraîchir l'écran pour afficher les options
    refresh();
	int a = 1;
    // Boucle principale
    while (a) {
		ch = getch();
        switch (ch) {
            case KEY_MOUSE: // Si un événement de souris est détecté
                if (getmouse(&event) == OK) {
                    if (event.bstate & BUTTON1_CLICKED) { // Si clic gauche
                        x = event.x;
                        y = event.y;

                        if (y == 2 && x >= 10 && x <= 20) {
                            mvprintw(9, 10, "Leaderboard");
							return 5;
						}
                        if (y == 3 && x >= 10 && x <= 20) {
                            mvprintw(9, 10, "Niveaux accelerants");
							return 1;
                        } else if (y == 4 && x >= 10 && x <= 20) {
                            mvprintw(9, 10, "Vitesse idéale");
							return 2;
                        } else if (y == 5 && x >= 10 && x <= 20) {
                            mvprintw(9, 10, "Vous avez sélectionné 2 joueurs");
							return 3;
						} else if (y == 6 && x >= 10 && x <= 20) {
                            mvprintw(9, 10, "Vous avez sélectionné bye");
							return 4;
                        } else {
                            mvprintw(9, 10, "Clique en dehors des options.");
                        }

                        // Rafraîchir l'écran pour mettre à jour les messages
                        refresh();
                    }
                }
                break;
        }
    }
	usleep(10000);
	endwin();
    return 0;
}
//initialise la vu ncurses avec toutes les fonctions de base de ncurses
void init_vue_ncurses(){
	initscr();
	cbreak();
	noecho();
	curs_set(0);
	init_colors();
	keypad(stdscr, TRUE);    
	mousemask(ALL_MOUSE_EVENTS | REPORT_MOUSE_POSITION, NULL); 
}
//gère l'affichage ncurses
void display_ncurses(int **matrice,int score,int niveau_act,int lives,int lives_p2){
	display_board(matrice);
    display_score(score,niveau_act);
    display_life(lives);
	display_life_p2(lives_p2);
}
//écran de fin de parties plus ajout du score au leaderboard si meilleur score
void end_screen(int score,int choix,int lives,int lives_p2,int niveau){
	if (choix == 3){
		if (lives <= 0)mvprintw(9,10,"Le joueur 2 a gagné Bravo! Il lui restait %d vies",lives_p2);
		else mvprintw(9,10,"Le joueur 1 a gagné Bravo! Il lui restait %d vies",lives);
	}
	else {
		mvprintw(9,10,"Vous avez perdu avec un score de %.2f",calc_score(score,niveau)*37.5);
	}
	refresh();
	char *nom = (char*)calloc(50,sizeof(char));
	get_player_name_ncurses(nom,50);
	insert_leaderboard(calc_score(score, niveau) * 37.5,nom);
	//usleep(3000000);
	clear();
}
//affiche le tableau des scores avec ncurses
void display_leaderboard_ncurses(ScoreThing *scores, int count) {
	clear();
    mvprintw(1, 5, "Leaderboard");
    for (int i = 0; i < count; i++) {
        mvprintw(3 + i, 5, "%s : %d", scores[i].name, scores[i].score);
    }
    mvprintw(5 + count, 5, "Attendez pour quitter.");
	refresh();
	usleep(6000000);
	clear();
}
// permet dans lancer la série de fonction permettant d'afficher le tableau des score
void init_leaderboard_ncurses(){
	ScoreThing *scores =(ScoreThing*)malloc(sizeof(ScoreThing)*MAX_ENTRIES);
	if (!scores) {
		printf("Erreur : allocation mémoire échouée pour le leaderboard.\n");
		return;
	}
	int count = load_scores("src/leaderboard.txt",scores);
	display_leaderboard_ncurses(scores,count);
	free(scores);
}
//récupère le nom du joueur avec ncurses
void get_player_name_ncurses(char *name, int max_length){
    int ch;
    int index = 0;
    memset(name, 0, max_length);
    mvprintw(5, 5, "Entrez votre nom (max %d caracteres) :", max_length - 1);
    move(7, 5); 

    while ((ch = getch()) != '\n') { 
        if (ch == KEY_BACKSPACE || ch == 127 || ch == '\b') {
            if (index > 0) {
                index--;
                name[index] = '\0';
                mvprintw(7, 5, "%-*s", max_length, name); 
                move(7, 5 + index); 
            }
        } else if (index < max_length - 1 && ch >= 32 && ch <= 126) {
            name[index++] = ch;
            name[index] = '\0'; 
            mvprintw(7, 5, "%s", name);
        }
    }
}