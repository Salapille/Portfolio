#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ncurses.h>
#include <math.h>
#include <unistd.h>

#include "vue_sdl.h"

#define MAX_ENTRIES 100
#define WIDTH 800
#define LENGTH 600
#define CELL_SIZE sqrt((WIDTH*LENGTH)/(get_width()*get_length()))
#define BUTTON_WIDTH 400
#define BUTTON_HEIGHT 50
#define BUTTON_MENU_X 200

// Fonction pour vérifier si un clic est dans un bouton
bool is_inside(int mouse_x, int mouse_y, Button button) {
    return mouse_x >= button.x && mouse_x <= (button.x + button.w) &&
           mouse_y >= button.y && mouse_y <= (button.y + button.h);
}

// Fonction pour dessiner un bouton
void draw_button(SDL_Renderer* renderer, Button button, SDL_Color color) {
    SDL_Rect rect = {button.x, button.y, button.w, button.h};
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, 255);
    SDL_RenderFillRect(renderer, &rect);
}
//affiche le menu de choix sdl
int sdl_menu(SDL_Window *window,SDL_Renderer *renderer,TTF_Font *font) {
    Button buttons[] = {
        {BUTTON_MENU_X, 200, BUTTON_WIDTH, BUTTON_HEIGHT, "Niveaux accelerants"},
        {BUTTON_MENU_X, 300, BUTTON_WIDTH, BUTTON_HEIGHT, "Vitesse ideale"},
        {BUTTON_MENU_X, 400, BUTTON_WIDTH, BUTTON_HEIGHT, "deux joueurs"},
        {BUTTON_MENU_X, 500, BUTTON_WIDTH, BUTTON_HEIGHT, "quitter"},
        {BUTTON_MENU_X, 100, BUTTON_WIDTH, BUTTON_HEIGHT, "learderboard"}
    };
    SDL_Color text_color = {255, 255, 255, 255}; 
    // Couleurs
    SDL_Color button_color = {0, 128, 255};   // Bleu clair
    SDL_Color background_color = {0, 0, 0};  // Noir

    bool running = true;
    SDL_Event event;
    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            } else if (event.type == SDL_MOUSEBUTTONDOWN) {
                int mouse_x = event.button.x;
                int mouse_y = event.button.y;

                for (int i = 0; i < 5; i++) {
                    if (is_inside(mouse_x, mouse_y, buttons[i])) {
                        switch(i){
                            case 0:return 1;
                            case 1:return 2;
                            case 2:return 3;
                            case 3:return 4;
                            case 4:return 5;
                            default:printf("help");
                        }
                    }
                }
            }
        }
        SDL_SetRenderDrawColor(renderer, background_color.r, background_color.g, background_color.b, 255);
        SDL_RenderClear(renderer);

        // Dessiner les boutons
        for (int i = 0; i < 5; i++) {
            draw_button(renderer, buttons[i], button_color);
        }
        display_text(renderer, "Leaderboard",BUTTON_WIDTH/8+BUTTON_MENU_X, 100, text_color,font);
        display_text(renderer, "Niveaux accelerants",BUTTON_WIDTH/8+BUTTON_MENU_X, 200, text_color,font);
        display_text(renderer, "Vitesse ideale",BUTTON_WIDTH/8+BUTTON_MENU_X, 300, text_color,font);
        display_text(renderer, "Deux joueurs",BUTTON_WIDTH/8+BUTTON_MENU_X, 400, text_color,font);
        display_text(renderer, "Quitter",BUTTON_WIDTH/8+BUTTON_MENU_X, 500, text_color,font);
        SDL_RenderPresent(renderer);
    }
    usleep(3000000);
    return -1;
}
//permet d'affiche la matrice sdl
void display_mat_sdl(int **mat,SDL_Renderer *renderer ){
    int width = get_width();
	int length = get_length();
    for (int i = 0; i < length; i++) {
        for (int j = 0; j < width; j++) {
            setColorByValue(renderer, mat[i][j]);

            SDL_Rect cell = {
                j * CELL_SIZE,    // Position X
                i * CELL_SIZE,    // Position Y
                CELL_SIZE,        // Largeur
                CELL_SIZE         // Hauteur
            };

            // Dessiner la cellule
            SDL_RenderFillRect(renderer, &cell);
        }
    }
}
//gère les couleurs de l'affichage sdl pour la matrice
void setColorByValue(SDL_Renderer *renderer, int value) {
    switch (value) {
        case 1: SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); break;   // Rouge
        case 2: SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255); break;   // Bleu
        case 3: SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255); break;   // Vert
        case 4: SDL_SetRenderDrawColor(renderer, 0, 255, 255, 255); break; // Cyan
        default: SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0); break; // Black
    }
}
//permet d'initialiser TTF pour les affichages textes
TTF_Font *init_ttf() {
    if (TTF_Init() == -1) {
        printf("Erreur SDL_ttf : %s\n", TTF_GetError());
        return NULL;
    }
    TTF_Font *font = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 24);
    if (!font) {
        printf("Erreur lors du chargement de la police : %s\n", TTF_GetError());

        return NULL;
    }
    return font;
}
//affiche le texte avec TTF a pour but d'êter réutilisé pour les autres affichages
void display_text(SDL_Renderer *renderer, const char *text, int x, int y, SDL_Color color,TTF_Font *font) {

    SDL_Surface *surface = TTF_RenderText_Solid(font, text, color);
    if (!surface) {
        //printf("Erreur lors de la création de la surface du texte : %s\n", TTF_GetError());
        return;
    }

    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        printf("Erreur lors de la création de la texture du texte : %s\n", SDL_GetError());
        SDL_FreeSurface(surface);
        return;
    }

    int text_width = surface->w;
    int text_height = surface->h;

    SDL_Rect dstrect = {x, y, text_width, text_height};
    SDL_RenderCopy(renderer, texture, NULL, &dstrect);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(surface);
}
//affichage du score avec sdl
void display_score_sdl(SDL_Renderer *renderer, TTF_Font *font, int score, int niveau) {
    int x = 10;
    int y = 10;
    float score_calculated = calc_score(score, niveau) * 37.5;

    char score_text[50];
    snprintf(score_text, sizeof(score_text), "Score : %.2f", score_calculated);

    char niveau_text[50];
    snprintf(niveau_text, sizeof(niveau_text), "Niveau : %d", niveau);

    SDL_Color text_color = {255, 255, 255, 255}; 
    display_text(renderer, score_text, x, y, text_color, font);
    display_text(renderer, niveau_text, LENGTH/2, y, text_color, font);
}
//affichage de la vie avec sdl
void display_life_sdl(SDL_Renderer *renderer, TTF_Font *font, int lives,int lives_p2) {
    int x = LENGTH/4 + LENGTH/2;
    int y = 10;
    char life_text[50];
    snprintf(life_text, sizeof(life_text), "Vie j1: %d Vie j2: %d", lives,lives_p2);

    SDL_Color text_color = {255, 255, 255, 255}; 

    display_text(renderer, life_text, x, y, text_color, font);
}
//initilise la fenêtre sdl
SDL_Window *init_window(){
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("Erreur SDL_Init: %s\n", SDL_GetError());
        exit(1);
    }

    // Créer une fenêtre
    SDL_Window *window = SDL_CreateWindow(
        "Thron",                
        SDL_WINDOWPOS_CENTERED,         // Position X
        SDL_WINDOWPOS_CENTERED,         // Position Y
        WIDTH,                            // Largeur
        LENGTH,                            // Hauteur
        SDL_WINDOW_SHOWN                // Flags
    );

    if (!window) {
        printf("Erreur SDL_CreateWindow: %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
    }
    return window;
}
//initilaise le renderer
SDL_Renderer *init_renderer(SDL_Window *window){
    SDL_Renderer *renderer = SDL_CreateRenderer(
        window, -1, SDL_RENDERER_ACCELERATED
    );
    if (!renderer) {
        printf("Erreur SDL_CreateRenderer: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        exit(1);
    }
    return renderer;
}
//libère la mémoire et efface tout ce qui est lié à la vue
void destroy_sdl(SDL_Window *window,SDL_Renderer *renderer){
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}
//boucle récurrentes permettants d'actualiser visuelement le jeu
void display_loop(int **matrice,SDL_Renderer *renderer,SDL_Window *window,TTF_Font *font,int score,int niveau_act,int lives,int lives_p2){
    display_mat_sdl(matrice, renderer);
    display_score_sdl(renderer,font,score,niveau_act);
    display_life_sdl(renderer,font,lives,lives_p2);
    SDL_RenderPresent(renderer);
}
//affichage lors de la perte d'une vie par le joueur 1
void display_hit(SDL_Renderer *renderer,TTF_Font *font){
    SDL_Color text_color = {255, 255, 255, 255}; 
    display_text(renderer, "Collision detectee j1 a perdu une vie",WIDTH/6, 300, text_color,font);
    SDL_RenderPresent(renderer);
    usleep(100000);
}
//affichage du level_up dans les modes liés
void display_lv_up(SDL_Renderer *renderer,TTF_Font *font){
    SDL_Color text_color = {255, 255, 255, 255}; 
    display_text(renderer, "Collision de l'ia detectee niveau suivant",WIDTH/6, 300, text_color,font);
    SDL_RenderPresent(renderer);
    usleep(100000);
}
//affichage en cas de collision de la part de l'ia ou du joueur2
void display_ia_collide(SDL_Renderer *renderer,TTF_Font *font,int choice){
    SDL_Color text_color = {255, 255, 255, 255}; 
    if (choice!=3)display_text(renderer, "Collision de l'ia detectee ",WIDTH/5, 300, text_color,font);
    display_text(renderer, "Collision detectee j2 a perdu une vie",WIDTH/5, 300, text_color,font);
    
    SDL_RenderPresent(renderer);
    usleep(200000);
}
//affichage de l'écran de fin de partie et ajout du score dans le leaderboard
void end_game_screen(SDL_Renderer *renderer,TTF_Font *font,int lives,int lives_p2,int choix,int score,int niveau){
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);

    char life_text[100];
    if (choix == 3){
        if (lives <= 0)snprintf(life_text, sizeof(life_text), "Le joueur 2 a gagne Bravo! Il lui restait %d vies", lives_p2);
        else snprintf(life_text, sizeof(life_text), "Le joueur 1 a gagne Bravo! Il lui restait %d vies", lives);
    } else {
        snprintf(life_text, sizeof(life_text), "Vous avez perdu avec un score de %.2f", calc_score(score, niveau) * 37.5);
    }
    SDL_Color text_color = {255, 255, 255}; 

    display_text(renderer, life_text, 100, 100, text_color, font);
    SDL_RenderPresent(renderer);

    char *nom =(char *)calloc(50,sizeof(char));
    get_player_name_sdl(renderer,font,nom,50);
    insert_leaderboard(calc_score(score, niveau) * 37.5,nom);
	//usleep(3000000);
}
//affiche le tableau des score
void display_leaderboard_sdl(SDL_Renderer *renderer, TTF_Font *font,ScoreThing *scores, int count){
    SDL_RenderClear(renderer);
    SDL_Color text_color = {255, 255, 255}; 
    int x = 100;
    int y = 50;  

    display_text(renderer, "Leaderboard", x, y, text_color, font);
    y += 50; 

    char buffer[100];
    for (int i = 0; i < count; i++) {
        snprintf(buffer, sizeof(buffer), "%s : %d", scores[i].name, scores[i].score);
        display_text(renderer, buffer, x, y, text_color, font);
        y += 30; 
    }
    SDL_RenderPresent(renderer);
}
//permet de lancer les fonctions permettant de gérer l'affichage du tableau des score
void init_leaderboard_sdl(SDL_Renderer *renderer,TTF_Font *font){
	ScoreThing *scores =(ScoreThing*)malloc(sizeof(ScoreThing)*MAX_ENTRIES);
    if (!scores) {
        printf("Erreur : allocation mémoire échouée pour le leaderboard\n");
        return;
    }
	int count = load_scores("src/leaderboard.txt",scores);
	display_leaderboard_sdl(renderer,font,scores,count);
    usleep(6000000);
    free(scores);
}
//récupère le nom à mettre dans le leaderbord
void get_player_name_sdl(SDL_Renderer *renderer, TTF_Font *font,char *name, int max_length){
    SDL_Event event;
    int running = 1;
    unsigned name_length = 0;

    SDL_Color text_color = {255, 255, 255, 255};
    SDL_Color background_color = {0, 0, 0, 255};

    SDL_StartTextInput();

    while (running) {
        SDL_SetRenderDrawColor(renderer, background_color.r, background_color.g, background_color.b, 255);
        SDL_RenderClear(renderer);


        display_text(renderer, "Entrez votre nom :", 50, 50, text_color, font);
        display_text(renderer, name, 50, 100, text_color, font);

        SDL_RenderPresent(renderer);

        // Traiter les événements
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = 0;
            } else if (event.type == SDL_KEYDOWN) {
                // Gérer la suppression (backspace)
                if (event.key.keysym.sym == SDLK_BACKSPACE && name_length > 0) {
                    name[--name_length] = '\0';
                }
                // Gérer l'entrée (entrée ou retour chariot)
                else if (event.key.keysym.sym == SDLK_RETURN || event.key.keysym.sym == SDLK_KP_ENTER) {
                    running = 0; // Fin de la saisie
                }
            } else if (event.type == SDL_TEXTINPUT) {
                if (name_length < max_length - 1) {
                    strcat(name, event.text.text);
                    name_length += strlen(event.text.text);
                }
            }
        }
    }
    SDL_StopTextInput();
}