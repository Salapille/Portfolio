#pragma once
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ncurses.h>

#include "../modele/modele.h"


void display_board(int **tab);
void display_border(int i,int j);
void display_player(int i,int j);
void display_ai(int i ,int j);

void display_score(int score,int niveau);
void display_life(int life);

void display_menu();
void init_colors();
int menu_ncurses();
void init_vue_ncurses();
void display_ncurses(int **matrice,int score,int niveau_act,int lives,int lives_p2);
void display_life_p2(int life_p2);
void end_screen(int score,int choix,int lives,int lives_p2,int niveau);
void init_leaderboard_ncurses();
void get_player_name_ncurses(char *name, int max_length);