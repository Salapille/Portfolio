#pragma once
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ncurses.h>

#define MAX_NAME_LENGTH 50
typedef struct player{
	int x;
	int y;
	char type;
}player;

typedef struct {
    char name[MAX_NAME_LENGTH];
    int score;
}ScoreThing;

void end_game();
int get_width();
int get_length();


int **init_tab();
void init_wall(int **tab);

int collision(int x2,int y2,int **tab);

int collision_player(int x2,int y2,int **tab);
int collision_ai(int x2,int y2,int **tab);
//faire un calcul avec temps actuel - temps de départ
int calc_score(int time,int niveau);

void actualisation(player *play,int x,int y,int **tab);
void nettoyage(int **mat);
int loose_life(int ** matrice,int lives,char *argv);

int load_scores(const char *filename,ScoreThing *scores);
void insert_leaderboard(int score,char *name);
void insert_score(ScoreThing *scores, int count,char *name, int score);
void save_scores(char *filename,ScoreThing *scores, int count);

void init_music();