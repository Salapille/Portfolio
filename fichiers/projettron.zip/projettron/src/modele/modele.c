#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ncurses.h>
#include <unistd.h>

#include "modele.h"


#define WIDTH 20
#define LENGTH 15
#define MAX_NAME_LENGTH 50
#define MAX_LINE_LENGTH 100
#define MAX_ENTRIES 100

//récupère la largeeur du terrain de jeu
int get_width(){
	return (int)WIDTH;
}
//récupère la longueur du terrain de jeu
int get_length(){
	return (int)LENGTH;
}
//initialise la matrice qui est le terrain de jeu
int **init_tab() {
    int **tableau = (int **)malloc(LENGTH * sizeof(int *));
    for (int i = 0; i < LENGTH; i++) {
        tableau[i] = (int *)calloc(WIDTH, sizeof(int));
		if(!tableau[i]){
			perror("problème d'allocation mémoire dans la matrice");
			exit(1);
		}
    }
	if (!tableau){
		perror("problème d'allocation mémoire de la matrice");
		exit(1);
	}
	init_wall(tableau);
    return tableau;
}
//gere les limites du jeu
void init_wall(int **tab){
	int width = get_width();
	int length = get_length();
	for(unsigned i = 0;i<length;i++){
		for(unsigned j = 0;j<width;j++){
			if (i == 0 || j == 0 || i ==length-1 || j ==width-1){
				tab[i][j]=3;
			}
		}
	}
}
//permet de vérifier les collisions en fonction des coordonnées
int collision(int x2, int y2, int **tab) {
    if (tab[x2][y2] != 0) return 1;
    if (x2 <= 0 || x2 >= LENGTH-1) return 1;  
    if (y2 <= 0 || y2 >= WIDTH) return 1;   
    return 0; 
}


void end_game(){
	return;
}
//gère la collision du joueur
int collision_player(int x2,int y2,int **tab){
	if (collision(x2,y2,tab))return 1;
	return 0;
}
//gère la collision de l'ia
int collision_ai(int x2,int y2,int **tab){
	if (collision(x2,y2,tab))return 1;
	return 0;
}
//modifie la matrice en fonction des déplacements des joueurs
void actualisation(player *play,int xn,int yn,int **tab){
	switch(play->type){
		case 'j' :if (!collision_player(xn,yn,tab)){
			//printf("entre dans j\n");
			tab[xn][yn] =1;
			play->x = xn;
			play->y = yn;
			}
			else end_game();
		case 'i' : if (!collision_ai(xn,yn,tab)){
			tab[xn][yn] =2;
			play->x = xn;
			play->y = yn;
		}
			else end_game();
	}
	//display_board(tab);
}
//calcul le score en fonction du niveau
int calc_score(int time,int niveau){
	return time*(niveau*(1/2)+1);
}
//permet de libérer la mémoire de la matrice
void nettoyage(int **mat){
	for (int i = 0; i < LENGTH; i++) {
		free(mat[i]);
	}
	free(mat);
}
//vérifie si le joueur a perdu la partie après avoir perdu la partie
int loose_life(int ** matrice,int lives,char *argv){
	if (lives>0){
		if (strcmp(argv, "n") == 0){
			mvprintw(get_length() + 2, 0, "Collision détectée ! Joueur 1 perds une vie");
			refresh();
		}
		usleep(3000000);
		nettoyage((matrice));
		return 1;
	}
	if (strcmp(argv, "n") == 0){
		mvprintw(get_length() + 2, 0, "Collision détectée ! Fin du jeu.");
		refresh();
	}
	usleep(3000000);
	endwin();
	nettoyage((matrice));
	clear();
	return 0;
}

//permet de charger les score du le fichier cible
int load_scores(const char *filename,ScoreThing *scores){
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Erreur : impossible d'ouvrir le fichier %s\n", filename);
        return -1;
    }

    int count = 0;
    char line[MAX_LINE_LENGTH];

    while (fgets(line, sizeof(line), file) && count < MAX_ENTRIES){
        line[strcspn(line, "\n")] = '\0';
        if (sscanf(line, "%49s %d", scores[count].name, &scores[count].score) == 2) {
            count++;
        } else {
            //printf("Ligne ignorée : %s\n", line);
        }
    }
    fclose(file);
    return count;
}
//fonction qui va lancer les autres fonctions permettant l'ajout ou non d'un score dans le leaderboard
void insert_leaderboard(int score,char *name){
	//char *name = "player1";
	ScoreThing *scores =(ScoreThing*)malloc(sizeof(ScoreThing)*MAX_ENTRIES);
	if (!scores) {
		printf("Erreur : allocation mémoire échouée pour le leaderboard.\n");
		return;
	}
	int count = load_scores("src/leaderboard.txt",scores);
	insert_score(scores,count,name,score);
	save_scores("src/leaderboard.txt",scores,count);
	free(scores);
}
//rajoute un score dans la liste de scores si il est plus grand que le plus petit score
//supprime le dernier score si un score est ajouté
void insert_score(ScoreThing *scores, int count,char *name, int score){
    if (count >= MAX_ENTRIES) {
        if (score <= scores[count - 1].score) {
            return;
        }
        (count)--; 
    }
    int pos = count;
    for (int i = 0; i < count; i++) {
        if (score > scores[i].score) {
            pos = i;
            break;
        }
    }
    for (int i = count; i > pos; i--) {
        scores[i] = scores[i - 1];
    }
    strncpy(scores[pos].name, name, MAX_NAME_LENGTH - 1);
    scores[pos].name[MAX_NAME_LENGTH - 1] = '\0';
    scores[pos].score = score;

    (count)++;
}

//sauvegarde les score dans un fichier texteune fois ScoreThing modifié
void save_scores(char *filename,ScoreThing *scores, int count){
    FILE *file = fopen(filename, "w");
    if (!file) {
        printf("Erreur : impossible d'écrire dans le fichier %s\n", filename);
        return;
    }

    for (int i = 0; i < count; i++) {
        fprintf(file, "%s %d\n", scores[i].name, scores[i].score);
    }

    fclose(file);
}

void init_music(){
	if (SDL_Init(SDL_INIT_AUDIO) < 0) {
        fprintf(stderr, "Erreur d'initialisation de SDL : %s\n", SDL_GetError());
        return ;
    }

    if (Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        fprintf(stderr, "Erreur d'initialisation de SDL_mixer : %s\n", Mix_GetError());
        SDL_Quit();
        return ;
    }

    // Charger un fichier audio
    Mix_Music *music = Mix_LoadMUS("electropvp.mp3");
    if (!music) {
        fprintf(stderr, "Impossible de charger la musique : %s\n", Mix_GetError());
        Mix_CloseAudio();
        SDL_Quit();
        return ;
    }

    // Lancer la musique
    Mix_PlayMusic(music, -1);
}
