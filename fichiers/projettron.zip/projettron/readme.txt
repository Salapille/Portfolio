La vidéo étant trop lourde pour le moment je vais devoir la publier sur youtube pour envoyer le lien pour l'instant je met uniquement le projet ou cas ou

Ce projet a pour but de faire le jeu TRON 
Je n'ai pas fait ce travail en groupe car au moment de chercher quelqu'un pour le faire un problème personnel m'a un peu sorti de tout ça j'espère que vous pourrez comprendre cordialement Noé
