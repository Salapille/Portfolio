import requests
from bs4 import BeautifulSoup
import psycopg2
from datetime import datetime
import locale

locale.setlocale(locale.LC_TIME, "fr_FR.UTF-8")
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host=""
)

# Création d'un curseur pour exécuter des requêtes SQL
cur = conn.cursor()

id_site = ""
nom_site=""
date_construction=""
adresse_site=""
ville_site=""
code_postal_site=00000
capacite_site= -1
site_web_site=""
# URL de la page Wikipedia
url = "https://fr.wikipedia.org/wiki/Site_d%27escalade_du_Bourget"
site_web_site= url
# Obtenir le contenu de la page
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')

# Trouver la div avec la classe "infobox_v3 noarchive large"
infobox_div = soup.find('div', class_='infobox_v3 noarchive large')
magic_box = []
# Si la div est trouvée, accéder à la première table à l'intérieur
if infobox_div:
    first_table = infobox_div.find('table')
    
    # Si une table est trouvée, accéder à la première div à l'intérieur
    if first_table:
        first_div = first_table.find('div')
        
        # Si une div est trouvée à l'intérieur de la table, récupérer les informations textuelles jusqu'à <br>
        if first_div:
            text_data = ""
            for item in first_div.strings:
                if item.strip() == "":
                    continue
                if "<br" in str(item):
                    break
                magic_box.append(item.strip())
                text_data += item.strip() + " "
    
    #pour la capa
liste_info = []
if infobox_div:
    td_elements = infobox_div.find_all('td')
    
    # Afficher le contenu des éléments <td>
    for td in td_elements:
        liste_info.append(td.text.strip())

entete_div = soup.find('div', class_='entete')


third_div = entete_div

# Extraire le texte de la troisième div sans les balises
nom_site = third_div.get_text(strip=True)
time_tag = soup.find('time', class_='nowrap')

# Si la balise time est trouvée, récupérer son contenu textuel
if time_tag:
    date_construction = time_tag.text.strip()

a = magic_box[0].split(',')
magic_box = a  
id_site = 4
liste_info = liste_info[:len(liste_info)-5]
capacite_site = liste_info[len(liste_info)-1]
adresse_site = magic_box[0]
code_postal_site = magic_box[1]
ville_site = magic_box[2]

print(id_site)
print(nom_site)
print(date_construction)
print(adresse_site)
print(ville_site)
print(code_postal_site)
print(capacite_site)
print(site_web_site)

capacite_site = capacite_site.replace("\xa0", " ")
capacite_site = int(capacite_site.replace(" ", ""))
date_construction = datetime.strptime(date_construction, "%d %B %Y").date()
date_construction = date_construction.strftime("%Y-%m-%d")

cur.execute("""
    INSERT INTO Site (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site)
    VALUES (%s,%s, %s, %s, %s, %s, %s, %s)
""", (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site))

# Valider la transaction
conn.commit()

# Fermer le curseur et la connexion
cur.close()
conn.close()
