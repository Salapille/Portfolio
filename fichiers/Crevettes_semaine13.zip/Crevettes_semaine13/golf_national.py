import requests
from bs4 import BeautifulSoup
import psycopg2
from datetime import datetime
import locale

locale.setlocale(locale.LC_TIME, "fr_FR.UTF-8")
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host=""
)

# Création d'un curseur pour exécuter des requêtes SQL
cur = conn.cursor()

id_site = ""
nom_site=""
date_construction=""
adresse_site=""
ville_site=""
code_postal_site=00000
capacite_site= -1
site_web_site=""
# URL de la page Wikipedia
url = "https://fr.wikipedia.org/wiki/Golf_national"
site_web_site= url
# Obtenir le contenu de la page
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')


infobox_div = soup.find('div', class_='infobox_v3 noarchive large')
magic_box = []


response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')


table_balise = soup.find('table', class_='infobox_v2 noarchive')


sixth_tr = table_balise.find_all('tr')[5]  

# Extraire tous les <td> à l'intérieur du sixième <tr>
td_list = sixth_tr.find_all('td')

# Afficher le contenu de chaque <td>
for element in sixth_tr.stripped_strings:
    # Vérifier si l'élément contient une balise <br>
    if '<br>' in element:
        # Séparer le texte en fonction de la balise <br>
        elements = element.split('<br>')
        # Ajouter chaque élément à la liste avec une séparation claire
        for sub_element in elements:
            magic_box.append(sub_element.strip())
    else:
        # Ajouter l'élément à la liste
        magic_box.append(element.strip())

  
    
    #pour la capa
liste_info = []
if infobox_div:
    td_elements = infobox_div.find_all('td')
    
    # Afficher le contenu des éléments <td>
    for td in td_elements:
        liste_info.append(td.text.strip())

td_balise = soup.find('td', {'colspan': '2', 'class': 'entete golf'})
if td_balise:
    nom_site = td_balise.get_text(strip=True)



time_tag = soup.find('time', class_='nowrap')

# Si la balise time est trouvée, récupérer son contenu textuel
if time_tag:
    date_construction = time_tag.text.strip()



id_site = 3
liste_info = liste_info[:len(liste_info)-5]
adresse_site = magic_box[1]
code_postal_site = magic_box[2]
ville_site = magic_box[3]
print(id_site)
print(nom_site)
print(date_construction)
print(adresse_site)
print(ville_site)
print(code_postal_site)
print(capacite_site)
print(site_web_site)

'''
capacite_site = capacite_site.replace("\xa0", " ")
capacite_site = int(capacite_site.replace(" ", ""))
'''
date_construction = datetime.strptime(date_construction, "%d %B %Y").date()
date_construction = date_construction.strftime("%Y-%m-%d")

cur.execute("""
    INSERT INTO Site (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site)
    VALUES (%s,%s, %s, %s, %s, %s, %s, %s)
""", (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site))

# Valider la transaction
conn.commit()

# Fermer le curseur et la connexion
cur.close()
conn.close()
