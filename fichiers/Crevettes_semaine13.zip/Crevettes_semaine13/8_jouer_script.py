"""
Associe à un athlète une épreuve de façon aléatoire

script de la table jouer :  
DROP TABLE IF EXISTS Jouer ;
CREATE TABLE Jouer (
id_athlete SERIAL REFERENCES Athlete,
id_epreuve SERIAL REFERENCES Epreuve,
PRIMARY KEY (id_athlete,  id_epreuve)
);
"""
from bs4 import BeautifulSoup
import psycopg2
from random import randint

NB_ATHLETES = 9717
NB_EPREUVES = 1

if __name__ == '__main__':
    ############ Identifiants pour la base de données ############
    conn = psycopg2.connect(
        dbname="jo2024",
        user="postgres",
        password="os27!Man06",
        host="localhost"
    )
    ##############################################################
    cur = conn.cursor()
    cur.execute("TRUNCATE jouer RESTART IDENTITY;")
    for i in range(NB_ATHLETES):
        cur.execute("INSERT INTO jouer (id_athlete, id_epreuve) VALUES (%s, %s)", (i+1, randint(1, NB_EPREUVES)))
        conn.commit()
    cur.close()
    conn.close()
