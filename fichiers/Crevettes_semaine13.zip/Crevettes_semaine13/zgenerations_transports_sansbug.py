import requests
from bs4 import BeautifulSoup
import psycopg2
from datetime import datetime
import locale
import re
import csv
import math

locale.setlocale(locale.LC_TIME, "fr_FR.UTF-8")
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host=""
)


def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371.0
    
    lat1 = math.radians(lat1)
    lon1 = math.radians(lon1)
    lat2 = math.radians(lat2)
    lon2 = math.radians(lon2)
    
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    
    # Formule de la haversine
    a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    distance = R * c
    distance = distance * 1000
    distance = math.floor(distance)
    if distance > 50000:
        distance  = 0
    int(distance)
    return distance


fichier_csv = "arret_metro.csv"
liste_metro = []
liste_bus = []
liste_train = []
valeurs_uniques = set()

with open(fichier_csv, newline='') as csvfile:
    lecteur_csv = csv.reader(csvfile, delimiter=';')  


    next(lecteur_csv)

    for ligne in lecteur_csv:

        derniere_valeur = ligne[10]
        nom_arret_ligne = ligne[4]
        valeurs_uniques.add((nom_arret_ligne,derniere_valeur))


for valeur in valeurs_uniques:
    liste_metro.append(valeur)


print(liste_metro)


fichier_csv = "arrets_bus.csv"
liste_bus = []

valeurs_uniques2 = set()

with open(fichier_csv, newline='') as csvfile:
    lecteur_csv = csv.reader(csvfile, delimiter=';')  


    next(lecteur_csv)

    for ligne in lecteur_csv:

        derniere_valeur = ligne[10]
        nom_arret = ligne[4]
        valeurs_uniques2.add((nom_arret,derniere_valeur))


for valeur in valeurs_uniques2:
    liste_bus.append(valeur)

print(liste_bus)


fichier_csv = "arrets_train.csv"
liste_train = []

valeurs_uniques3 = set()

with open(fichier_csv, newline='') as csvfile:
    lecteur_csv = csv.reader(csvfile, delimiter=';')  


    next(lecteur_csv)

    for ligne in lecteur_csv:

        derniere_valeur = ligne[10]
        nom_arret = ligne[4]
        valeurs_uniques3.add((nom_arret,derniere_valeur))


for valeur in valeurs_uniques3:
    liste_train.append(valeur)

print(liste_train)


cur = conn.cursor()
id_site = 0
id_arret = 0
liste_nom = []
liste_id_arret = []
ancien_id_arret = 0
noms_a_ignorer =["Paris 2024","made in France"]
liste_coord = ['','48.78800979, 2.03498269','43.2698, 5.3959','48.7532, 2.0758','48.93693402, 2.41997931','44.8974, -0.5616','48.924475, 2.360127','45.76514165, 4.98199275','47.25593494, -1.52469927','43.7051, 7.1926','45.4607, 4.3902','50.61190661, 3.13047318','48.832968, 2.2840069','48.84156974, 2.253048697','43.2661, 5.3678','48.8531, 2.30252','48.86616355, 2.3125474','48.8954, 2.2294','48.8997292, 2.3605141','48.8386, 2.3751','48.81432266, 2.08452588','48.83863, 2.378597','48.8623, 2.6348','48.85972558, 2.29221884','48.8563881, 2.35222203','48.85613, 2.2978','48.78981063, 1.9642379','46.8157, 1.7582','48.86573765, 2.3220383','48.86616355, 2.3125474','-17.86693, -149.25208','48.832968, 2.2840069','48.830184, 2.289033','48.829381, 2.290865','48.845968, 2.253522','48.845968, 2.253522','48.845968, 2.253522','','48.9721, 2.5149','48.92934371, 2.24777122','48.845968, 2.253522']
liste_url=["","https://www.paris2024.org/fr/site/velodrome-national-saint-quentin-en-yvelines/","https://www.paris2024.org/fr/site/centre-aquatique/","https://www.paris2024.org/fr/site/golf-national/","https://www.paris2024.org/fr/site/site-escalade-bourget/","https://www.paris2024.org/fr/site/stade-bordeaux/","https://www.paris2024.org/fr/site/stade-de-france/","https://www.paris2024.org/fr/site/stade-lyon/","https://www.paris2024.org/fr/site/stade-nantes/","https://www.paris2024.org/fr/site/stade-nice/","https://www.paris2024.org/fr/site/stade-geoffroy-guichard/","https://www.paris2024.org/fr/site/stade-pierre-mauroy/","https://www.paris2024.org/fr/site/stade-roland-garros/","https://www.paris2024.org/fr/site/parc-des-princes/","https://www.paris2024.org/fr/site/marina-marseille/","https://www.paris2024.org/fr/site/arena-champ-de-mars/","https://www.paris2024.org/fr/site/grand-palais/","https://www.paris2024.org/fr/site/paris-la-defense-arena/","https://www.paris2024.org/fr/site/arena-la-chapelle/","https://www.paris2024.org/fr/site/arena-bercy/","https://www.paris2024.org/fr/site/chateau-de-versailles/?trk=public_post_comment-text","https://www.paris2024.org/fr/site/invalides/","https://www.paris2024.org/fr/site/hotel-de-ville/","https://www.paris2024.org/fr/site/trocadero/","https://www.paris2024.org/fr/site/pont-alexandre-iii/","https://www.paris2024.org/fr/site/stade-tour-eiffel/","https://www.paris2024.org/fr/site/colline-elancourt/","https://www.paris2024.org/fr/site/centre-national-tir-chateauroux/","https://www.paris2024.org/fr/site/parc-urbain-la-concorde/","https://www.paris2024.org/fr/site/stade-nautique-de-vaires-sur-marne/","https://www.paris2024.org/fr/site/tahiti-teahupoo/","https://www.paris2024.org/fr/site/arena-paris-sud/","https://www.paris2024.org/fr/site/arena-paris-sud/","https://www.paris2024.org/fr/site/arena-paris-sud/","https://www.paris2024.org/fr/site/stade-roland-garros/","https://www.paris2024.org/fr/site/stade-roland-garros/","https://www.paris2024.org/fr/site/stade-roland-garros/","https://www.paris2024.org/fr/site/arena-paris-nord/","https://www.paris2024.org/fr/site/arena-paris-nord/","https://www.paris2024.org/fr/site/stade-yves-du-manoir/?fs=e&s=cl","https://www.paris2024.org/fr/site/stade-marseille/"]
for j in range(1,(len(liste_url))):
    id_site += 1
    
    if id_site != 38 :
        url = liste_url[id_site]
        response = requests.get(url)
    


    soup = BeautifulSoup(response.text, 'html.parser')

    div_wrap = soup.find('div', class_='wrap')

    if div_wrap:
        text_elements = div_wrap.find_all(string=True)
        full_text = ' '.join(text_elements).strip()
        ancien_text = full_text
        if "«" in full_text and j != 37:
            full_text = full_text.split("«")[1:]
            '''s
            if j == 26:
                print(full_text)
                full_text = full_text[0].split(",")[0]
                print(full_text)
            '''
            last = full_text[-1].split(".")[0]
            full_text = full_text[:-1]
            full_text.append(last)
            print(j)
            
            if j in (5,27,29,28,26):
                full_text = full_text[:-1]
            if j == 28:
                full_text = full_text[1:]
            if j == 23:
                full_text.pop(len(full_text)-2)
            for i in range(len(full_text)):
                a = full_text[i].split('»')
                nom_arret = a[0]
                check = a[0].strip()
                if check in ("Paris 2024","made in France"):
                    continue
                print(nom_arret)
                deja_vu = False
                id_arret =1 + ancien_id_arret
                ancien_id_arret =id_arret
                for f in range(len(liste_nom)):
                    if liste_nom[f] == nom_arret:
                        e = liste_id_arret[f]
                        id_arret = e
                        deja_vu = True
                if deja_vu == False:
                    liste_id_arret.append(id_arret)
                    liste_nom.append(nom_arret)
                
                if "étro" or "ram" in a[1]:
                    distance_metro_site = 0
                    for elem in liste_metro:
                        if nom_arret.strip() in elem[0].strip():
                            print(elem[1])
                            print(liste_coord[id_site])
                            distance_metro_site =haversine_distance(float(elem[1].split(',')[0]),float(elem[1].split(',')[1]),float(liste_coord[id_site].split(',')[0]),float(liste_coord[id_site].split(',')[1]))
                            print(distance_metro_site)
                            distance_metro_site= round(distance_metro_site, 2)
                    if deja_vu == True:
                        cur.execute("""
                        INSERT INTO PrendreMetro (id_site,id_arret_metro,distance_metro_site)
                        VALUES (%s,%s,%s)
                        """,(id_site,id_arret,distance_metro_site))
                        conn.commit()
                    if deja_vu == False:
                        cur.execute("""
                        INSERT INTO Arret_Metro (id_arret_metro,nom_arret_metro)
                        VALUES (%s,%s)
                        """,(id_arret,nom_arret))
                        conn.commit()
                        cur.execute("""
                        INSERT INTO PrendreMetro (id_site,id_arret_metro,distance_metro_site)
                        VALUES (%s,%s,%s)
                        """,(id_site,id_arret,distance_metro_site))
                        conn.commit()
                if "bus" or "Bus" in a[1] :
                    distance_bus_site = 0
                    for elem in liste_bus:
                        if j not in (6,7,8,9,10,11,37):
                            if nom_arret.strip() in elem[0].strip():
                                print(elem[1])
                                print(liste_coord[id_site])
                                distance_bus_site =haversine_distance(float(elem[1].split(',')[0]),float(elem[1].split(',')[1]),float(liste_coord[id_site].split(',')[0]),float(liste_coord[id_site].split(',')[1]))
                                print(distance_bus_site)
                                distance_bus_site= round(distance_bus_site, 2)
                    if deja_vu == True:
                        cur.execute("""
                        INSERT INTO PrendreBus (id_site,id_arret_bus)
                        VALUES (%s,%s)
                        """,(id_site,id_arret))
                        conn.commit()
                    else:
                        cur.execute("""
                        INSERT INTO Arret_Bus (id_arret_bus,nom_arret_bus)
                        VALUES (%s,%s)
                        """,(id_arret,nom_arret))
                        conn.commit()
                        cur.execute("""
                        INSERT INTO PrendreBus (id_site,id_arret_bus)
                        VALUES (%s,%s)
                        """,(id_site,id_arret))
                        conn.commit()
                if "rain" in a[1]:
                    distance_train_site = 0
                    for elem in liste_train:
                        if j not in (6,7,8,9,10,11,37):
                            if nom_arret.strip() in elem[0].strip():
                                print(elem[1])
                                print(liste_coord[id_site])
                                distance_train_site =haversine_distance(float(elem[1].split(',')[0]),float(elem[1].split(',')[1]),float(liste_coord[id_site].split(',')[0]),float(liste_coord[id_site].split(',')[1]))
                                print(distance_train_site)
                                distance_train_site= round(distance_train_site, 2)
                    if deja_vu == True:
                        cur.execute("""
                        INSERT INTO PrendreTrain (id_site,id_gare)
                        VALUES (%s,%s)
                        """,(id_site,id_arret))
                        conn.commit()
                    else :
                        cur.execute("""
                        INSERT INTO Gare (id_gare,nom_gare)
                        VALUES (%s,%s)
                        """,(id_arret,nom_arret))
                        conn.commit()
                        cur.execute("""
                        INSERT INTO PrendreTrain (id_site,id_gare)
                        VALUES (%s,%s)
                        """,(id_site,id_arret))
                        conn.commit()


def extraire_texte(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            textes_extraits = set()
            texte_guillemets = re.findall(r'«([^»]*)»', response.text)
            if texte_guillemets:
                for texte in texte_guillemets:
                    texte_strip = texte.strip()
                    textes_extraits.add(texte_strip)
            return textes_extraits
        else:
            print("Échec de la requête. Statut de la réponse :", response.status_code)
            return set()  
    except Exception as e:
        print("Une erreur s'est produite :", e)
        return set()  


url = "https://www.stade-pierre-mauroy.com/infos-pratiques/acces"


textes_extraits = extraire_texte(url)


deja_vu = False
ancien_id_arret = 0 

liste_nom = []
liste_id_arret = []
id_site = 11
for nom_arret in textes_extraits:
    id_arret = 100+id_arret
    deja_vu = False
    for f in range(len(liste_nom)):
        if liste_nom[f] == nom_arret:
            e = liste_id_arret[f]
            id_arret = e
            deja_vu = True
    if deja_vu == False:
        liste_id_arret.append(id_arret)
        liste_nom.append(nom_arret)
    if deja_vu == True:
        cur.execute("""
        INSERT INTO PrendreMetro (id_site,id_arret_metro)
        VALUES (%s,%s)
        """,(id_site,id_arret))
        conn.commit()
    if deja_vu == False:
        cur.execute("""
        INSERT INTO Arret_Metro (id_arret_metro,nom_arret_metro)
        VALUES (%s,%s)
        """,(id_arret,nom_arret))
        conn.commit()
        cur.execute("""
        INSERT INTO PrendreMetro (id_site,id_arret_metro)
        VALUES (%s,%s)
        """,(id_site,id_arret))
        conn.commit()

url = "https://www.stade-pierre-mauroy.com/infos-pratiques/acces"


extraire_texte(url)

# Valider la transaction
conn.commit()

# Fermer le curseur et la connexion
cur.close()
conn.close()








