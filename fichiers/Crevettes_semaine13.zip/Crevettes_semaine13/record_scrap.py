"""
récupère tous les records des JO entre 2022 et 2000
Les athlètes n'étant pas présents (ou très rarement) dans la base athlete sont choisis aléatoirement pour les records
même s'ils ne pratiquent pas la bonne épreuvre.
script de la table record :
DROP TABLE IF EXISTS Record cascade ; 
CREATE TABLE Record (
id_record INTEGER NOT NULL UNIQUE,
dernier_record VARCHAR,
detenteur_du_dernier_titre_olympique INTEGER NOT NULL REFERENCES Athlete,
id_epreuve INTEGER NOT NULL REFERENCES Epreuve,
detenteur_record INTEGER NOT NULL REFERENCES Athlete,
PRIMARY KEY (id_record)
);
"""

import requests
from bs4 import BeautifulSoup
import psycopg2
import time
import json
import os.path
from random import randint

NB_ATHLETES = 9717
NB_EPV = 351

def sauvegarder_dictionnaire(dictionnaire, nom_fichier):
    """Sauvegarde un dictionnaire dans un fichier texte au format JSON."""
    with open(nom_fichier, 'w') as fichier:
        json.dump(dictionnaire, fichier)

def charger_dictionnaire(nom_fichier):
    """Charge un dictionnaire depuis un fichier texte au format JSON."""
    with open(nom_fichier, 'r') as fichier:
        dictionnaire = json.load(fichier)
    return dictionnaire

start_time = time.time()
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.76 Safari/537.36', "Upgrade-Insecure-Requests": "1","DNT": "1","Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language": "en-US,en;q=0.5","Accept-Encoding": "gzip, deflate"}


if not os.path.isfile("record_scrap_dico_genere"):
    print("création du dictionnaire pour toutes les urls, prend un certain temps...")
#+----------------------------------------------+#
#         récupérer tous les jo passés          |#
    print("I.")
    jo_dico = {}
    url = "https://olympics.com/fr/olympic-games/tokyo-2020/results/athletisme"
    response = requests.get(url,headers=headers, timeout=5, allow_redirects = True )
    soup = BeautifulSoup(response.text, "html.parser")
    script = soup.find_all("script")[-1].text
    for i in range(12):
        ind = script.find("a\",\"slug\":\"")
        res = script[ind:ind+50]
        jo_tmp = res[11:11+res[11:].find("\"")]
        jo_dico[jo_tmp] = None
        script = script[ind+1:]
#|                                              |#
#+----------------------------------------------+#
#|  récupérer le nom de toutes les disciplines  |#
    print("II.")
    for jo_tmp in jo_dico.keys():
        data_DE = {}
        url = "https://olympics.com/fr/olympic-games/" + jo_tmp + "/results"
        response = requests.get(url,headers=headers, timeout=5, allow_redirects = True )
        soup = BeautifulSoup(response.text, "html.parser")
        script = soup.find_all("script")[-1].text
        res = None
        b = 0
        while (b < 2) or (res not in jo_dico.keys()):
            b += 1
            ind = script.find("\"slug\":\"")
            res = script[ind+8:ind+10+script[ind+10:ind+100].find("\"")]
            data_DE[res] = []
            script = script[ind+1:]
        del data_DE[list(data_DE.keys())[0]]
        del data_DE[list(data_DE.keys())[-1]]
        jo_dico[jo_tmp] = data_DE
#|                                              |#
#+----------------------------------------------+#
#|récupérer pour chaque disciplines ses épreuves|#
    print("III.")
    for jo_tmp in jo_dico:
        print(jo_tmp)
        for dis in jo_dico[jo_tmp].keys():
            ########print(jo_tmp, dis)
            url = "https://olympics.com/fr/olympic-games/" + jo_tmp + "/results/" + dis
            response = requests.get(url,headers=headers, timeout=5, allow_redirects = True )
            soup = BeautifulSoup(response.text, "html.parser")
            script = soup.find_all("script")[-1].text
            res = None
            while res != "":
                ind = script.find("t\",\"slug\":\"")
                res = script[ind:ind+50]
                epreuve = res[11:11+res[11:].find("\"")]
                if (epreuve not in jo_dico[jo_tmp][dis]) and (epreuve != dis) and (epreuve != ''):
                    jo_dico[jo_tmp][dis].append(epreuve)
                script = script[ind+1:]
    sauvegarder_dictionnaire(jo_dico, "record_scrap_dico_genere")
    print("Dictionnaire généré et sauvegardé.")
else:
    jo_dico = charger_dictionnaire("record_scrap_dico_genere")
#|                                              |#
#+----------------------------------------------+#
#|       traitées les données du dico           |#
print("lancement du scraping...")

epreuves_dico = {}
cpt = 0
if not os.path.isfile("record_scrap_dico_data_traitees"):
    for jo in jo_dico.keys():
        print(cpt*(100/12),'%')
        cpt+=1
        for dis in jo_dico[jo].keys():
            for epv in jo_dico[jo][dis]:
                try:
                    response = requests.get("https://olympics.com/fr/olympic-games/"+jo+"/results/"+dis+"/"+epv,headers=headers, timeout=5, allow_redirects = True )
                    soup = BeautifulSoup(response.text, "html.parser")
                    
                    span_data_cy_element = soup.find("span", attrs={"data-cy": "result-info-content"})
                    if span_data_cy_element:
                        res = span_data_cy_element.text.strip()
                        if epv not in epreuves_dico:
                            epreuves_dico[epv] = []
                        epreuves_dico[epv].append(res)
                except:
                    continue
    sauvegarder_dictionnaire(epreuves_dico, "record_scrap_dico_data_traitees")
    print("Dictionnaire de données traitées, généré et sauvegardé.")
#|                                              |#
#+----------------------------------------------+#
#|       ajout dans la base de données          |#

data_dico = charger_dictionnaire("record_scrap_dico_data_traitees")

############ Identifiants pour la base de données ############
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)
##############################################################
cur = conn.cursor()
cur.execute("TRUNCATE record RESTART IDENTITY CASCADE;")

CPT = 0
for epv in data_dico:
    for rec in data_dico[epv]:
        #print(epv, data_dico[epv][0], data_dico[epv][:])
        cur.execute("INSERT INTO record (id_record, dernier_record, detenteur_du_dernier_titre_olympique, id_epreuve, detenteur_record) VALUES (%s, %s, %s, %s, %s)", (CPT, rec, randint(1, NB_ATHLETES), randint(0, NB_EPV) ,randint(1, NB_ATHLETES)))
        CPT += 1
        conn.commit()                

end_time = time.time()
execution_time = end_time - start_time
print("\nTemps d'exécution :", execution_time, "secondes")

cur.close()
conn.close()