import requests
from bs4 import BeautifulSoup
import psycopg2
from googletrans import Translator

""" Si un erreur de type 'NoneType' object has no attribute 'group'
    Mettre à jour googletrans de cette manière
    Outils>Ouvrir la console du système> pip install googletrans==3.1.0a0
"""

def scrape_and_insert_data(url, column_index):
    response = requests.get(url)

    translator = Translator()

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find("table", class_="wikitable")

    if sports_table:
        rows = sports_table.find_all("tr")
        compt=0

        for row in rows:
            columns = row.find_all("th")
            columns_date = row.find_all("td")
            
            if columns[0].text.strip()!='Sport (Discipline)':
                if len(columns) > column_index and len(columns_date) >= 3:
                    discipline_name = columns[column_index].text.strip()
                    date = columns_date[1].text.strip()
                    name_en=translator.translate(discipline_name, dest='en').text
                    if (discipline_name != ""):
                        cur.execute("INSERT INTO Discipline VALUES (%s,%s,%s,%s)", (compt,discipline_name,name_en,'01/01/'+date))
                        conn.commit()
                        compt+=1
        return compt
                        
def scrape_and_insert_data_para(url,compt):
    response = requests.get(url)

    translator = Translator()

    soup = BeautifulSoup(response.text, "html.parser")

    sports = soup.find("div", class_="sports-container")

    if sports:
        rows = sports.find_all("div", class_="list-item")
        for row in rows:
            paragraphe=row.find("p",class_="title")
            discipline_name = paragraphe.text.strip()
            name_en=translator.translate(discipline_name, dest='en').text
            if (discipline_name != ""):
                cur.execute("INSERT INTO Discipline(id_discipline,nom_discipline,nom_anglais) VALUES (%s,%s,%s)", (compt,discipline_name,name_en,))
                conn.commit()
                compt+=1
                

conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)


cur = conn.cursor()
cur.execute("Truncate Discipline CASCADE;")

url_fr = "https://fr.wikipedia.org/wiki/Sports_olympiques"
url_para = "https://france-paralympique.fr/parasports/"



compt=scrape_and_insert_data(url_fr, -1)
scrape_and_insert_data_para(url_para,compt)

cur.close()
conn.close()