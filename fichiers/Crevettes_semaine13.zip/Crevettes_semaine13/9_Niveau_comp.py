import requests
from bs4 import BeautifulSoup
import psycopg2

conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)

cur = conn.cursor()
cur.execute("Truncate Niveau_competition CASCADE;")
compt=0
for i in range(6):
    nom="1/"+str(int(32/2**(i)))
    if nom=="1/1":
        cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,"Finale"))
        conn.commit()
        compt+=1
    elif nom=="1/2":
        cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,nom + " Finale"))
        conn.commit()
        compt+=1
    elif nom=="1/4":
        cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,nom + " de Finale"))
        conn.commit()
        compt+=1
    else:
        cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,nom))
        conn.commit()
        compt+=1

cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,"Match pour la 3e place"))
conn.commit()
compt+=1

cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,"Tours Préliminaires"))
conn.commit()
compt+=1

for i in range(1,4):
    nom=str(i)+"er/eme Tours"
    cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,nom))
    conn.commit()
    compt+=1
    
cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,"Course aux médailles"))
conn.commit()
compt+=1

cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,"Régates"))
conn.commit()
compt+=1

cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,"Repêchages"))
conn.commit()
compt+=1

cur.execute("INSERT INTO Niveau_competition VALUES (%s,%s)", (compt,"Séries"))
conn.commit()
compt+=1

cur.close()
conn.close()