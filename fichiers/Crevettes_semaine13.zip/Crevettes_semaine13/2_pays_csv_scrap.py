"""
Ajoute à la base de données les informations de chaque pays contenus dans le fichier csv récupéré.

script de la table pays :
DROP TABLE IF EXISTS Pays ; 
CREATE TABLE Pays (
code_pays VARCHAR(3) NOT NULL UNIQUE,
nom_pays VARCHAR, 
population_pays INTEGER DEFAULT 0, 
PRIMARY KEY (code_pays)
);
"""
import csv
import psycopg2

############ Identifiants pour la base de données ############
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)
##############################################################
cur = conn.cursor()
cur.execute("TRUNCATE pays CASCADE;")
with open('countries.csv', newline='') as csvfile:
    csv_reader = csv.reader(csvfile, delimiter=';')
    next(csv_reader)
    for row in csv_reader:
        code_pays, nom_pays, _, _, population, *_ = row
        population = int(population.replace(',', ''))
        cur.execute("INSERT INTO Pays (code_pays, nom_pays, population_pays) VALUES (%s, %s, %s)", (code_pays, nom_pays, population))

conn.commit()

cur.close()
conn.close()