import csv

# Chemin vers le fichier CSV
fichier_csv = "parisSites.csv"

# Ensemble pour stocker les valeurs uniques de la dernière colonne
valeurs_uniques = set()
# Ouvrir le fichier CSV en mode lecture
with open(fichier_csv, newline='') as csvfile:
    lecteur_csv = csv.reader(csvfile, delimiter=';')  # Supposant que le délimiteur est un point-virgule

    # Ignorer l'en-tête du fichier CSV
    next(lecteur_csv)

    # Lire chaque ligne du fichier CSV
    for ligne in lecteur_csv:
        # Récupérer la dernière valeur de chaque ligne
        derniere_valeur = ligne[-1]

        # Ajouter la dernière valeur à l'ensemble
        valeurs_uniques.add(derniere_valeur)

# Afficher les valeurs uniques de la dernière colonne
for valeur in valeurs_uniques:
    print(valeur)
