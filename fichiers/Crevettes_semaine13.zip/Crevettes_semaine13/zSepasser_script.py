import csv
import psycopg2
from datetime import datetime
import locale


def read_csv(csv_path,start,end):
    with open(csv_path, 'r', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  
        data = list(reader)[start-1:end]
    return data


def connect_to_database():
    try:
        connection = psycopg2.connect(
        dbname="jo2024",
        user="postgres",
        password="os27!Man06",
        host="localhost"
    )
        return connection
    except (Exception, psycopg2.Error) as error:
        print("Erreur lors de la connexion à PostgreSQL :", error)
        
def convert_string_to_postgresql_date(input_string):
    mois_fr_to_en = {
        'Janvier': 'January',
        'Février': 'February',
        'Mars': 'March',
        'Avril': 'April',
        'Mai': 'May',
        'Juin': 'June',
        'Juillet': 'July',
        'Août': 'August',
        'Septembre': 'September',
        'Octobre': 'October',
        'Novembre': 'November',
        'Décembre': 'December'
    }
    
    jour_fr_to_en = {
        'Lundi': 'Monday',
        'Mardi': 'Tuesday',
        'Mercredi': 'Wednesday',
        'Jeudi': 'Thursday',
        'Vendredi': 'Friday',
        'Samedi': 'Saturday',
        'Dimanche': 'Sunday'
    }
    
    

    for mois_fr, mois_en in mois_fr_to_en.items():
        if mois_fr in input_string:
            input_string = input_string.replace(mois_fr, mois_en)
            
    for jour_fr, jour_en in jour_fr_to_en.items():
        if jour_fr in input_string:
            input_string = input_string.replace(jour_fr, jour_en)
    
    date_object = datetime.strptime(input_string, '%A %d %B')
    
    postgresql_date = date_object.strftime('2024-%m-%d')
    
    return postgresql_date

def split_hours(hours_string):
    start_hour, end_hour = hours_string.split('-')
    return start_hour.strip(), end_hour.strip()

def split_hours_err(hours_string):
    parts = hours_string.split(':')
    start_hour = parts[0] + ":" + parts[1]
    end_hour = parts[2] + ":" + parts[3]
    return start_hour, end_hour

def insert_data_into_database(connection, data, stade, discipline,liste_date,indice_finale,indice_demi,indice_quart,liste_bronze):
    cursor = connection.cursor()
    compt=0
    for nb_ligne in range(len(data)):
        for nb_colonne in range(4,len(data[nb_ligne])):
            if data[nb_ligne][nb_colonne]!="" :
                start,end=split_hours(data[nb_ligne][nb_colonne])
                if compt in liste_bronze:
                    cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, discipline, 6, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))
                if compt in indice_finale:
                    cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, discipline, 5, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))
                elif compt in indice_demi:
                    cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, discipline, 4, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))

                elif compt in indice_quart:
                    cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, discipline, 3, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))
                    
                else:
                    cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, discipline, 7, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))

                compt+=1
                connection.commit()
    
def insert_data_into_database_sport_poid(connection, data, stade, liste_discipline,liste_date,indice_finale,indice_demi,indice_quart,liste_bronze):
    cursor = connection.cursor()
    compt=0
    for nb_ligne in range(len(data)):
        indice=0
        for nb_colonne in range(4,len(data[nb_ligne])):
            if data[nb_ligne][nb_colonne]!="" and data[nb_ligne][nb_colonne][:8]!='Horaires':
                if (len(data[nb_ligne][nb_colonne])>=4):
                    if len(data[nb_ligne][nb_colonne])>=46:
                        start,end=split_hours(data[nb_ligne][nb_colonne][24:36])
                    elif data[nb_ligne][nb_colonne][5]==":" and data[nb_ligne][nb_colonne][6]=="-":
                        start,end=split_hours_err(data[nb_ligne][nb_colonne])
                        start,end=split_hours(start+end)
                    elif data[nb_ligne][nb_colonne][5]==":":
                        start,end=split_hours_err(data[nb_ligne][nb_colonne])
                    else:
                        start,end=split_hours(data[nb_ligne][nb_colonne])
                    if compt in liste_bronze:
                        cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, liste_discipline[indice%len(liste_discipline)], 6, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))
                        indice+=1
                    elif compt in indice_finale:
                        cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, liste_discipline[indice%len(liste_discipline)], 5, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))
                        indice+=1
                    elif compt in indice_demi:
                        cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, liste_discipline[indice%len(liste_discipline)], 4, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))
                        indice+=1
                    elif compt in indice_quart:
                        cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, liste_discipline[indice%len(liste_discipline)], 3, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))
                        indice+=1
                    else:
                        cursor.execute("INSERT INTO Sepasser (id_site, id_epreuve, id_niveau, date_epreuve, heure_epreuve_debut, heure_epreuve_fin) VALUES (%s,%s,%s,%s,%s,%s)", (stade, liste_discipline[indice%len(liste_discipline)], 7, convert_string_to_postgresql_date(liste_date[nb_colonne-4]),start,end))
                        indice+=1
                    compt+=1

    connection.commit()
    
def recup_date(data):
    liste_date=[]
    for i in range(len(data)):
        for j in range(3,len(data[i])):
            if j>=12:
                liste_date.append(data[i][j]+" Août")
            else:
                liste_date.append(data[i][j]+" Juillet")
    return liste_date

def remove_newlines(input_string):
    return input_string.replace('\n', ' ')

def remove_heure(input_string):
    return input_string.replace('-', ' ')

def enlever(chaine):
    for i in range(len(chaine)):
        chaine[i]=remove_newlines(chaine[i])

csv_path = 'donnees_extraits.csv'
csv_path2 = 'page_2.csv'
csv_path3 = 'page_3.csv'

data = read_csv(csv_path,3,3)
data_bv = read_csv(csv_path,7,11)
data_judo = read_csv(csv_path,12,13)
data_lutte = read_csv(csv_path,15,16)
data_escrime= read_csv(csv_path,17,19)
data_taekwondo= read_csv(csv_path,20,23)
data_l_arc=read_csv(csv_path,24,27)
data_cycle=read_csv(csv_path,28,28)
data_mara=read_csv(csv_path,30,30)
data_tria=read_csv(csv_path,32,32)
data_mara_nat=read_csv(csv_path,34,34)
data_cycle_route=read_csv(csv_path,37,37)
data_basket_3=read_csv(csv_path,39,42)
data_break=read_csv(csv_path,44,45)
data_bmx_free=read_csv(csv_path,47,47)
data_skate=read_csv(csv_path,49,50)
data_skate_park=read_csv(csv_path,52,53)
data_tennis=read_csv(csv_path,55,56)
data_tennis2=read_csv(csv_path,57,57)
data_tennis3=read_csv(csv_path,58,58)
data_tennis4=read_csv(csv_path,59,59)
data_boxe2=read_csv(csv_path,61,62)
data_v=read_csv(csv_path,64,67)
data_tennis_table=read_csv(csv_path,69,71)
data_hand=read_csv(csv_path,73,75)
data_halte=read_csv(csv_path,77,79)
data_grith=read_csv(csv_path,81,83)
data_grith2=read_csv(csv_path2,3,3)
data_bask2=read_csv(csv_path2,8,11)
data_bad=read_csv(csv_path2,13,15)
data_grith3=read_csv(csv_path2,17,18)
data_nat=read_csv(csv_path2,20,21)
data_wat=read_csv(csv_path2,23,25)
data_nat_r=read_csv(csv_path2,27,27)
data_plong=read_csv(csv_path2,29,30)
data_wat2=read_csv(csv_path2,32,34)
data_athle=read_csv(csv_path2,36,37)
data_rugby=read_csv(csv_path2,39,40)
data_esca=read_csv(csv_path2,42,43)
data_boxe=read_csv(csv_path2,45,47)
data_penta2=read_csv(csv_path2,49,49)
data_bmx_rac=read_csv(csv_path2,51,51)
data_vtt=read_csv(csv_path2,53,53)
data_golf=read_csv(csv_path2,55,55)
data_cycle_piste=read_csv(csv_path2,57,58)
data_equi=read_csv(csv_path2,60,60)
data_penta=read_csv(csv_path2,62,63)
data_avi=read_csv(csv_path2,65,65)
data_c_ligne=read_csv(csv_path2,67,67)
data_c_sla=read_csv(csv_path2,69,69)
data_hockey=read_csv(csv_path2,71,74)
data_basket2=read_csv(csv_path2,75,78)
data_hand2=read_csv(csv_path2,80,84)
data_tir=read_csv(csv_path2,86,87)
data_fosse=read_csv(csv_path2,88,88)
data_voile=read_csv(csv_path3,3,3)
data_surf=read_csv(csv_path3,5,5)
data_foot1=read_csv(csv_path3,7,8)
data_foot2=read_csv(csv_path3,10,10)
data_foot3=read_csv(csv_path3,12,13)
data_foot4=read_csv(csv_path3,15,15)
data_foot5=read_csv(csv_path3,17,17)
data_foot6=read_csv(csv_path3,19,19)
data_foot7=read_csv(csv_path3,21,21)


connection = connect_to_database()
cursor = connection.cursor()
cursor.execute("Truncate Sepasser;")
date=recup_date(data)
enlever(date)

insert_data_into_database_sport_poid(connection, data_bv, 25 , list(range(83, 85)) ,date,[38,39],[25,37],[23,24,35,36],[])
insert_data_into_database_sport_poid(connection, data_judo,15 , list(range(137, 150)) ,date,list(range(8,16)),[],[],[])
insert_data_into_database_sport_poid(connection, data_lutte,15 , list(range(126, 136)) ,date,[6,8,9,10,11,12],[],[],[])
insert_data_into_database_sport_poid(connection, data_escrime,16 , list(range(201, 212)) ,date,list(range(9,18)),[],[],[])
insert_data_into_database_sport_poid(connection, data_taekwondo,16 , list(range(108, 115)) ,date,list(range(9,13)),[],[],[])
insert_data_into_database_sport_poid(connection, data_l_arc,21 , list(range(299,304)) ,date,[10,11,15,16,17],[],[],[])
insert_data_into_database(connection, data_cycle, 21, 176 ,date,[0],[],[],[])
insert_data_into_database(connection, data_mara, 22 , 30 ,date,[0],[],[],[])
insert_data_into_database_sport_poid(connection, data_tria,24 , list(range(316, 319)) ,date,[0],[],[],[])
insert_data_into_database_sport_poid(connection, data_mara_nat,24 , list(range(273, 275)) ,date,[0],[],[],[])
insert_data_into_database_sport_poid(connection, data_cycle_route,23 , list(range(187, 189)) ,date,[0],[],[],[])
insert_data_into_database_sport_poid(connection, data_bask2, 28 , list(range(69,71)) ,date,[17],[16,15],[14,13,12,11],[])
insert_data_into_database_sport_poid(connection, data_break, 28 , list(range(151,153)) ,date,[2,3],[],[],[])
insert_data_into_database_sport_poid(connection, data_bmx_free, 28 , list(range(169,171)) ,date,[1],[],[],[])
insert_data_into_database_sport_poid(connection, data_skate, 28 , list(range(287,289)) ,date,[2,3],[],[],[])
insert_data_into_database_sport_poid(connection, data_skate_park, 28 , list(range(285,287)) ,date,[2,3],[],[],[])
insert_data_into_database_sport_poid(connection, data_tennis, 12 , list(range(291,296)) ,date,[7,8,15],[],[],[])
insert_data_into_database_sport_poid(connection, data_tennis2, 34 , list(range(291,296)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_tennis3, 35 , list(range(291,296)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_tennis4, 36 , list(range(291,296)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_boxe2, 35 , list(range(171,173)) ,date,[0],[],[],[])
insert_data_into_database_sport_poid(connection, data_v, 31 , list(range(81,83)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_tennis_table, 32 , list(range(296,299)) ,date,[15,19,20,25,26],[],[],[])
insert_data_into_database_sport_poid(connection, data_hand, 33 , list(range(71,73)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_halte, 33 , list(range(116,126)) ,date,[0],[],[],[])
insert_data_into_database_sport_poid(connection, data_grith, 19 , list(range(229,231)) ,date,[3,6,7],[],[],[])
insert_data_into_database_sport_poid(connection, data_grith2, 19 , list(range(229,231)) ,date,[2,3,4,5],[],[],[])
insert_data_into_database_sport_poid(connection, data_basket_3, 19 , list(range(69,71)) ,date,[10,15],[14,9],[13,12,8,7],[4,5])
insert_data_into_database_sport_poid(connection, data_bad, 18 , list(range(62,67)) ,date,[9,16,17,18,19],[],[],[])
insert_data_into_database_sport_poid(connection, data_grith3, 18 , list(range(229,231)) ,date,[2,4],[],[],[])
insert_data_into_database_sport_poid(connection, data_nat, 17 , list(range(231,268)) ,date,list(range(8,17)),[],[],[])
insert_data_into_database_sport_poid(connection, data_wat, 17 , list(range(77,79)) ,date,[7,8],[6,13],[5,4,12,11],[0,1])
insert_data_into_database_sport_poid(connection, data_nat_r, 2 , list(range(269,272)) ,date,[2,4],[],[],[])
insert_data_into_database_sport_poid(connection, data_plong, 2 , list(range(275,283)) ,date,[0,1,2,3,11,13,14,15],[],[],[])
insert_data_into_database_sport_poid(connection, data_wat2, 17 , list(range(77,79)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_athle, 6 , list(range(0,30)) ,date,[8,9,10,11,12,13,14,15,16,17],[],[],[])
insert_data_into_database_sport_poid(connection, data_rugby, 6 , list(range(79,81)) ,date,[2,5],[],[],[])
insert_data_into_database_sport_poid(connection, data_esca, 4 , list(range(197,201)) ,date,[2,3,4,5],[],[],[])
insert_data_into_database_sport_poid(connection, data_boxe, 38 , list(range(171,173)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_penta, 38 , list(range(95,108)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_bmx_rac, 1 , list(range(171,173)) ,date,[1],[],[],[])
insert_data_into_database_sport_poid(connection, data_vtt, 26 , list(range(173,175)) ,date,[0,1],[],[],[])
insert_data_into_database_sport_poid(connection, data_golf, 3 , list(range(213,215)) ,date,[3,7],[],[],[])
insert_data_into_database_sport_poid(connection, data_cycle_piste, 1 , list(range(175,187)) ,date,[2,3,4,5,6,7,8],[],[],[])
insert_data_into_database_sport_poid(connection, data_equi, 20 , list(range(191,197)) ,date,[2,5,7,8,10],[],[],[])
insert_data_into_database_sport_poid(connection, data_penta, 20 , list(range(183,285)) ,date,[1,3],[],[],[])
insert_data_into_database_sport_poid(connection, data_avi, 29 , list(range(48,62)) ,date,[4,5,6,7],[],[],[])
insert_data_into_database_sport_poid(connection, data_c_ligne, 29 , list(range(153,163)) ,date,[2,3,4,5],[],[],[])
insert_data_into_database_sport_poid(connection, data_c_sla, 29 , list(range(163,168)) ,date,[1,2,4,5,8],[],[],[])
insert_data_into_database_sport_poid(connection, data_hockey, 39 , list(range(75,77)) ,date,[34,35],[11,33],[10,9,32,31],[12,13])
insert_data_into_database_sport_poid(connection, data_hand2, 11 , list(range(71,73)) ,date,[6,7],[10,11,14,15],[0,1,4,5,8,9,12,13],[2,3])
insert_data_into_database_sport_poid(connection, data_tir, 27 , list(range(304,308))+list(range(310,314)) ,date,[2,3,5,7,9,10,11,13],[],[],[])
insert_data_into_database_sport_poid(connection, data_fosse, 27 , list(range(308,310))+list(range(314,316)) ,date,[1,2,4,5,6],[],[],[])
insert_data_into_database_sport_poid(connection, data_voile, 14 , list(range(319,329)) ,date,[4,5,9,10,11],[],[],[])
insert_data_into_database_sport_poid(connection, data_surf, 30 , list(range(289,291)) ,date,[3],[],[],[])
insert_data_into_database_sport_poid(connection, data_foot1, 13 , list(range(73,75)) ,date,[8,9],[],[],[])
insert_data_into_database_sport_poid(connection, data_foot2, 8 , list(range(73,75)) ,date,[],[],[],[7])
insert_data_into_database_sport_poid(connection, data_foot3, 5 , list(range(73,75)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_foot4, 7 , list(range(73,75)) ,date,[],[],[],[10])
insert_data_into_database_sport_poid(connection, data_foot5, 10 , list(range(73,75)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_foot6, 40 , list(range(73,75)) ,date,[],[],[],[])
insert_data_into_database_sport_poid(connection, data_foot7, 9 , list(range(73,75)) ,date,[],[],[],[])

connection.close()