import requests
from bs4 import BeautifulSoup
import psycopg2
from datetime import datetime
import locale

locale.setlocale(locale.LC_TIME, "fr_FR.UTF-8")
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host=""
)

cur = conn.cursor()

id_site = ""
nom_site = ""
date_construction = "1 "
adresse_site = ""
ville_site = ""
code_postal_site = 00000
capacite_site = -1
site_web_site = ""

url = "https://fr.wikipedia.org/wiki/Palais_omnisports_de_Paris-Bercy"
site_web_site = url

response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')

infobox_div = soup.find('div', class_='infobox_v3 noarchive large')
magic_box = []

if infobox_div:
    first_table = infobox_div.find('table')
    
    next_sibling = first_table
    
    if next_sibling:
        first_div = first_table.find('div')
        for item in next_sibling.stripped_strings:
            magic_box.append(item)

magic_box3 = []
if infobox_div:
    tables = infobox_div.find_all('table')
    if len(tables) >= 2:
        second_table = tables[3]
        second_tr = second_table.find_all('tr')[1]
        second_td = second_tr.find_all('td')[0]
        for item in second_td.stripped_strings:
            magic_box3.append(item)

a = magic_box3[0].split(':')
capacite_site = a[1]

entete_div = soup.find('div', class_='entete')
third_div = entete_div
nom_site = third_div.get_text(strip=True)

time_tag = soup.find('time', class_='nowrap')
if time_tag:
    date_construction += time_tag.text.strip()
    date_construction.split()
    
date_construction = date_construction[0] + " janvier " + date_construction[10:]
id_site = 19
adresse_site = magic_box[-6] + " " + magic_box[-5]
ville_site = magic_box[-3]

print(id_site)
print(nom_site)
print(date_construction)
print(adresse_site)
print(ville_site)
print(code_postal_site)
print(capacite_site)
print(site_web_site)

capacite_site = capacite_site.replace("\xa0", " ")
capacite_site = int(capacite_site.replace(" ", ""))

# Formatter la date dans le format attendu par PostgreSQL
date_construction = datetime.strptime(date_construction, "%d %B %Y").date().strftime("%Y-%m-%d")

cur.execute("""
    INSERT INTO Site (id_site, nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
""", (id_site, nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site))

conn.commit()
cur.close()
conn.close()
