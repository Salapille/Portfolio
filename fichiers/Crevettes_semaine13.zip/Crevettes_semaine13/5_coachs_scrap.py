"""
Scrap les noms, prenoms de chaque coachs disposant de l'Attestation base athletique, présents dans la base de données d'Athle.
date_naissance et en_poste_depuis sont générés aléatoirements (manque d'informations)

script de la table Coach :
table utilisée 
DROP TABLE IF EXISTS Coach ;
CREATE TABLE Coach (
id_coach INT NOT NULL,
nom_coach VARCHAR,
prenom_coach VARCHAR,
date_naissance_coach DATE,
en_poste_depuis_coach DATE,
PRIMARY KEY (id_coach)
);
"""

import requests
from bs4 import BeautifulSoup
import psycopg2
from random import randint
from datetime import datetime, timedelta

CPT = 1

def traiter_nom_prenom(L):
    res = []
    for elt in L:
        if '(' not in elt and ')' not in elt and '.' not in elt and elt != '-':
            res.append(elt)
    nom = ""
    for elt in res[:-1]:
        nom += elt + ' '
    return nom, res[-1]

def generer_date(debut_annee, fin_annee):
    start_date = datetime(debut_annee, 1, 1)
    end_date = datetime(fin_annee, 12, 31)
    random_date = start_date + timedelta(days=randint(0, (end_date - start_date).days))
    return random_date.strftime("%Y-%m-%d")

def scraping_coachs(url, cur, conn):
    global CPT
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    coachs = soup.find_all('tr')[3:]
    for coach in coachs:
        try:
            cells = coach.find_all('td')
            print(cells[0].text.strip().split(maxsplit=1))
            nom, prenom = traiter_nom_prenom(cells[0].text.strip().split(maxsplit=1))
            date_naissance = generer_date(1960, 1990)
            en_poste_depuis = generer_date(2009, 2024)
            cur.execute("INSERT INTO Coach (id_coach, nom_coach, prenom_coach, date_naissance_coach, en_poste_depuis_coach) VALUES (%s, %s, %s, %s, %s)", (CPT, nom, prenom, date_naissance, en_poste_depuis))
            conn.commit()
            CPT += 1
        except:
            print(f"(coachs_scrap.py) changement de page à scraper {int(CPT/(1411/12))}/12 ou une erreur s'est produite")
            continue

############ Identifiants pour la base de données ############
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)
##############################################################
cur = conn.cursor()
cur.execute("TRUNCATE Coach RESTART IDENTITY CASCADE;")

base_url = "https://bases.athle.fr/asp.net/liste.aspx?frmpostback=true&frmbase=contacts&frmmode=1&frmespace=0&frmdomaine=ENTRAINEUR&frmsousdomaine=Attestation+Base+Athletique&frmligue=&frmdepartement=&frmnom=&frmemail="
for page_num in range(0, 12):
    url = base_url + f"&frmposition={page_num}"
    scraping_coachs(url, cur, conn)

cur.close()
conn.close()