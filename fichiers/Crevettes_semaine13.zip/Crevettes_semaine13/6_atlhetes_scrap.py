"""
Scrap les noms, prenoms, sexes et dates de naissances de chaque athlètes présents dans la base de données d'Athle.
Pays_code, id_coach et nb_titre_olympique_athlete sont générés aléatoirements (manque d'informations)

script de la table Athlete :
DROP TABLE IF EXISTS Athlete CASCADE;
CREATE TABLE Athlete (
id_athlete INT NOT NULL, 
nom_athlete VARCHAR, 
prenom_athlete VARCHAR, 
sexe_athlete CHAR, 
date_naissance_athlete DATE, 
nb_titre_olympique_athlete INT, 
pays_code VARCHAR REFERENCES Pays, 
id_coach SERIAL REFERENCES Coach, 
PRIMARY KEY (id_athlete)
);
"""
import requests
from bs4 import BeautifulSoup
import psycopg2
from random import choice, randint

# le nombre de coachs présents dans la table coach
NOMBRE_COACHS = 1273
PAYS_CODES = ['AD', 'AE', 'AF', 'AG', 'AI', 'AL', 'AM', 'AO', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AW', 'AX',
              'AZ', 'BA', 'BB', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ', 'BL', 'BM', 'BN', 'BO', 'BQ',
              'BR', 'BS', 'BT', 'BV', 'BW', 'BY', 'BZ', 'CA', 'CC', 'CD', 'CF', 'CG', 'CH', 'CI', 'CK',
              'CL', 'CM', 'CN', 'CO', 'CR', 'CU', 'CV', 'CW', 'CX', 'CY', 'CZ', 'DE', 'DJ', 'DK', 'DM',
              'DO', 'DZ', 'EC', 'EE', 'EG', 'EH', 'ER', 'ES', 'ET', 'FI', 'FJ', 'FK', 'FM', 'FO', 'FR',
              'GA', 'GB', 'GD', 'GE', 'GF', 'GG', 'GH', 'GI', 'GL', 'GM', 'GN', 'GP', 'GQ', 'GR', 'GS',
              'GT', 'GU', 'GW', 'GY', 'HK', 'HM', 'HN', 'HR', 'HT', 'HU', 'ID', 'IE', 'IL', 'IM', 'IN',
              'IO', 'IQ', 'IR', 'IS', 'IT', 'JE', 'JM', 'JO', 'JP', 'KE', 'KG', 'KH', 'KI', 'KM', 'KN',
              'KP', 'KR', 'XK', 'KW', 'KY', 'KZ', 'LA', 'LB', 'LC', 'LI', 'LK', 'LR', 'LS', 'LT', 'LU',
              'LV', 'LY', 'MA', 'MC', 'MD', 'ME', 'MF', 'MG', 'MH', 'MK', 'ML', 'MM', 'MN', 'MO', 'MP',
              'MQ', 'MR', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY', 'MZ', 'NA', 'NC', 'NE', 'NF', 'NG',
              'NI', 'NL', 'NO', 'NP', 'NR', 'NU', 'NZ', 'OM', 'PA', 'PE', 'PF', 'PG', 'PH', 'PK', 'PL',
              'PM', 'PN', 'PR', 'PS', 'PT', 'PW', 'PY', 'QA', 'RE', 'RO', 'RS', 'RU', 'RW', 'SA', 'SB',
              'SC', 'SD', 'SS', 'SE', 'SG', 'SH', 'SI', 'SJ', 'SK', 'SL', 'SM', 'SN', 'SO', 'SR', 'ST',
              'SV', 'SX', 'SY', 'SZ', 'TC', 'TD', 'TF', 'TG', 'TH', 'TJ', 'TK', 'TL', 'TM', 'TN', 'TO',
              'TR', 'TT', 'TV', 'TW', 'TZ', 'UA', 'UG', 'UM', 'US', 'UY', 'UZ', 'VA', 'VC', 'VE', 'VG',
              'VI', 'VN', 'VU', 'WF', 'WS', 'YE', 'YT', 'ZA', 'ZM', 'ZW', 'CS', 'AN'] # obtenu via pays_csv_scrap
CPT = 1

def traiter_nom_prenom(L):
    res = []
    for elt in L:
        if '(' not in elt and ')' not in elt and '.' not in elt and elt != '-':
            res.append(elt)
    nom = ""
    for elt in res[:-1]:
        nom += elt + ' '
    return nom, res[-1]

def traiter_date(date):
    if date == '':
        return None
    date = date.split('/')
    return date[2]+'-'+date[1]+'-'+date[0]

def scraping(url):
    global CPT
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    athletes = soup.find_all('tr')
    for i in range(3, len(athletes)):
        if (i%2==0):
            athlete = athletes[i].find_all('td', class_= 'datas1')
        else:
            athlete = athletes[i].find_all('td', class_= 'datas0')
        try:
            print(athlete[0].a.text.strip())
            nom, prenom = traiter_nom_prenom(athlete[0].a.text.strip().split())
            sexe = athlete[1].text.strip()
            date_naissance = traiter_date(athlete[2].text.strip())
            cur.execute("INSERT INTO athlete (id_athlete, nom_athlete, prenom_athlete, sexe_athlete, date_naissance_athlete, nb_titre_olympique_athlete, pays_code, id_coach) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)", (CPT, nom, prenom, sexe, date_naissance, randint(0,27),choice(PAYS_CODES), randint(1,NOMBRE_COACHS)))
            conn.commit()
            CPT += 1
        except:
            print(f"(athletes_scrap.py) changement de page à scraper {int(CPT/(9717/40))}/40 ou une erreur s'est produite")
            continue

############ Identifiants pour la base de données ############
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)
##############################################################
cur = conn.cursor()
cur.execute("TRUNCATE athlete RESTART IDENTITY CASCADE;")

url_homme = "https://bases.athle.fr/asp.net/liste.aspx?frmpostback=true&frmbase=selections&frmmode=1&frmespace=0&frmnom=&frmsexe=M&frmligue=&frmdepartement=&frmspecialite=&frmrencontre=&frmannee=&frmselection=&frmclubs=&frments=&frmposition=0"
url_femme = "https://bases.athle.fr/asp.net/liste.aspx?frmpostback=true&frmbase=selections&frmmode=1&frmespace=0&frmnom=&frmsexe=F&frmligue=&frmdepartement=&frmspecialite=&frmrencontre=&frmannee=&frmselection=&frmclubs=&frments=&frmposition=0"
sources_data = ([url_femme, 14], [url_homme, 26])

for data in sources_data:
    for i in range(data[1]):
        scraping(data[0])
        if i < 10:
            data[0] = data[0][:-1]+str(i+1)
        else:
            data[0] = data[0][:-2]+str(i+1)
cur.close()
conn.close()
