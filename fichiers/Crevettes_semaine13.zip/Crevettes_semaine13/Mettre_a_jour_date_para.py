import psycopg2

conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)

cur = conn.cursor()

disciplines_paralympiques_dates = {
    "Basket fauteuil": "1960",
    "Boccia": "1984",
    "Escrime fauteuil": "1960",
    "Football à 5": "2004",
    "Goalball": "1976",
    "Para athlétisme": "1960",
    "Para aviron": "2008",
    "Para badminton": "2020",
    "Para canoë kayak": "2016",
    "Para cyclisme": "1984",
    "Para développé couché": "1964",
    "Para équitation": "1996",
    "Para judo": "1988",
    "Para natation": "1960",
    "Para taekwondo": "2020",
    "Para tennis de table": "1960",
    "Para tir à l’arc": "1960",
    "Para tir sportif": "1976",
    "Para triathlon": "2016",
    "Rugby fauteuil": "2000",
    "Tennis fauteuil": "1992",
    "Volley assis": "1976",
}

for discipline, date in disciplines_paralympiques_dates.items():
    try:
        cur.execute("UPDATE Discipline SET date_creation_discipline = %s WHERE nom_discipline = %s", (date+'/01/01', discipline))
        conn.commit()
        print(f"Mise à jour réussie : {discipline} - Date d'introduction : {date}")
    except Exception as e:
        conn.rollback()
        print(f"Erreur lors de la mise à jour de {discipline}: {e}")

cur.close()
conn.close()