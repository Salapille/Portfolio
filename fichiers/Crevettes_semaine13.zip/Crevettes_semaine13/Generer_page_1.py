import csv
import pdfplumber

def extract_table_from_pdf(pdf_path, page_number):
    with pdfplumber.open(pdf_path) as pdf:
        page = pdf.pages[page_number]
        table = page.extract_tables()
    return table

def save_table_to_csv(table, csv_path):
    with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        for row in table:
            writer.writerows(row)

pdf_path = 'Calendrier-par-epreuves-des-Jeux-Olympiques-de-Paris-2024-1-1.pdf'

page_number = 0

table = extract_table_from_pdf(pdf_path, page_number)

csv_path = 'donnees_extraits.csv'

save_table_to_csv(table, csv_path)
