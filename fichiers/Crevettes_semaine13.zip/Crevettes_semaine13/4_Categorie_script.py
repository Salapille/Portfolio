import requests
from bs4 import BeautifulSoup
import psycopg2

def scrape_and_insert_data(url, column_index, compt,dep,arret,sexe):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find("table", class_="wikitable")

    if sports_table:
        rows = sports_table.find_all("tr")
        compt_ligne=0
    
        for row in rows:
                columns = row.find_all("td")
                if columns and compt_ligne<arret and compt_ligne>=dep :
                    if len(columns) > column_index:
                        categorie= columns[column_index].text.strip()
                        if categorie[0]=="M":
                            cur.execute("INSERT INTO Categorie VALUES (%s,%s,%s)", (compt,"- "+categorie[9:],sexe))
                            conn.commit()
                            compt+=1
                        elif categorie[0]=="P":
                            cur.execute("INSERT INTO Categorie VALUES (%s,%s,%s)", (compt,"+ "+categorie[8:],sexe))
                            conn.commit()
                            compt+=1
                        elif len(categorie)>2 and categorie[1]!=" " and categorie[2]!="–":
                            cur.execute("INSERT INTO Categorie VALUES (%s,%s,%s)", (compt,categorie[0]+" "+categorie[1:],sexe))
                            conn.commit()
                            compt+=1
                        elif categorie!='-':
                            cur.execute("INSERT INTO Categorie VALUES (%s,%s,%s)", (compt,categorie,sexe))
                            conn.commit()
                            compt+=1
                compt_ligne+=1
        return compt

conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)


cur = conn.cursor()
cur.execute("Truncate Categorie CASCADE;")

compt=0
dico_sexe=["Femme","Homme","Mixte"]
dico_categorie=["Individuel","En Equipe","A deux","A quatre"]
for i in range(0,len(dico_sexe)):
    for j in range(0,len(dico_categorie)):
        cur.execute("INSERT INTO Categorie VALUES (%s,%s,%s)", (compt,dico_categorie[j],dico_sexe[i]))
        compt+=1
        
url_boxe ="https://fr.wikipedia.org/wiki/Boxe_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_haltero="https://fr.wikipedia.org/wiki/Halt%C3%A9rophilie_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_karate ="https://fr.wikipedia.org/wiki/Karaté_aux_Jeux_olympiques"
url_taekwondo="https://fr.wikipedia.org/wiki/Taekwondo_aux_Jeux_olympiques"
url_judo="https://fr.wikipedia.org/wiki/Judo_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_lutte="https://fr.wikipedia.org/wiki/Lutte_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"

compt=scrape_and_insert_data(url_boxe,-1, compt,0,9,"Homme")
compt=scrape_and_insert_data(url_boxe, -1, compt,9,16,"Femme" )
cur.execute("INSERT INTO Categorie VALUES (%s,%s,%s)", (compt,"- 61kg","Homme"))
compt+=1
compt=scrape_and_insert_data(url_haltero, 0,compt,3,7,"Homme")
compt=scrape_and_insert_data(url_haltero, 0,compt,8,15,"Femme")
compt=scrape_and_insert_data(url_karate, 1,compt,0,4,"Homme")
compt=scrape_and_insert_data(url_karate, 2,compt,0,4,"Femme")
compt=scrape_and_insert_data(url_taekwondo, 1,compt,0,5,"Homme")
compt=scrape_and_insert_data(url_taekwondo, 2,compt,0,5,"Femme")
cur.execute("INSERT INTO Categorie VALUES (%s,%s,%s)", (compt,"- 60kg","Homme"))
compt+=1
compt=scrape_and_insert_data(url_judo,0,compt,3,4,'Homme')
compt=scrape_and_insert_data(url_judo,0,compt,5,9,'Homme')
compt=scrape_and_insert_data(url_judo,1,compt,9,10,'Femme')
compt=scrape_and_insert_data(url_judo,0,compt,10,16,'Femme')
compt=scrape_and_insert_data(url_lutte,0,compt,3,8,'Homme')
compt=scrape_and_insert_data(url_lutte,0,compt,9,10,'Femme')
compt=scrape_and_insert_data(url_lutte,0,compt,11,14,'Femme')

cur.close()
conn.close()