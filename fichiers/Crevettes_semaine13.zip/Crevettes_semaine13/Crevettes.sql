CREATE DATABASE jo2024;
\connect jo2024;

DROP TABLE IF EXISTS Pays ; 
CREATE TABLE Pays (
code_pays VARCHAR(2) NOT NULL UNIQUE,
nom_pays VARCHAR, 
population_pays INTEGER DEFAULT 400000, 
PRIMARY KEY (code_pays)
);

DROP TABLE IF EXISTS Discipline ; 
CREATE TABLE Discipline (
id_discipline INTEGER NOT NULL UNIQUE, 
nom_discipline VARCHAR, 
nom_anglais VARCHAR, 
date_creation_discipline DATE DEFAULT '1896/01/01' CHECK (date_creation_discipline>='1896/01/01'), 
PRIMARY KEY (id_discipline)
); 

DROP TABLE IF EXISTS Categorie ; 
CREATE TABLE Categorie (
id_categorie INTEGER NOT NULL UNIQUE, 
nom_categorie VARCHAR, 
sexe_categorie VARCHAR, 
PRIMARY KEY (id_categorie)
);

DROP TABLE IF EXISTS Coach ;
CREATE TABLE Coach (
id_coach INTEGER NOT NULL UNIQUE,
nom_coach VARCHAR,
prenom_coach VARCHAR,
date_naissance_coach DATE,
en_poste_depuis_coach DATE,
PRIMARY KEY (id_coach)
);

DROP TABLE IF EXISTS Athlete CASCADE ;
CREATE TABLE Athlete (
id_athlete INTEGER NOT NULL UNIQUE, 
nom_athlete VARCHAR, 
prenom_athlete VARCHAR, 
sexe_athlete CHAR, 
date_naissance_athlete DATE, 
nb_titre_olympique_athlete INTEGER DEFAULT 0, 
pays_code VARCHAR(2) REFERENCES Pays, 
id_coach INTEGER NOT NULL REFERENCES Coach, 
PRIMARY KEY (id_athlete)
);

DROP TABLE IF EXISTS Epreuve ;
CREATE TABLE Epreuve (
id_epreuve INTEGER NOT NULL UNIQUE,
nom_epreuve VARCHAR,
date_creation_epreuve DATE DEFAULT '1896/01/01' CHECK (date_creation_epreuve>='1896/01/01'),
id_categorie INTEGER NOT NULL REFERENCES Categorie, 
id_discipline INTEGER NOT NULL REFERENCES Discipline,
PRIMARY KEY (id_epreuve)
);

DROP TABLE IF EXISTS Record ; 
CREATE TABLE Record (
id_record INTEGER NOT NULL UNIQUE,
dernier_record VARCHAR,
detenteur_du_dernier_titre_olympique INTEGER NOT NULL REFERENCES Athlete,
id_epreuve INTEGER NOT NULL REFERENCES Epreuve,
detenteur_record INTEGER NOT NULL REFERENCES Athlete,
PRIMARY KEY (id_record)
);

DROP TABLE IF EXISTS Site ;
CREATE TABLE Site (
id_site INTEGER NOT NULL UNIQUE,
nom_site VARCHAR,
date_construction DATE,
adresse_site VARCHAR,
ville_site VARCHAR,
code_postal_site NUMERIC(5),
capacite_site INTEGER,
site_web_site VARCHAR,
PRIMARY KEY (id_site)
);

DROP TABLE IF EXISTS Arret_Bus ;
CREATE TABLE Arret_Bus (
id_arret_bus INTEGER NOT NULL UNIQUE,
nom_arret_bus VARCHAR,
PRIMARY KEY (id_arret_bus)
);

DROP TABLE IF EXISTS Gare ;
CREATE TABLE Gare (
id_gare INTEGER NOT NULL UNIQUE,
nom_gare VARCHAR,
PRIMARY KEY (id_gare)
);

DROP TABLE IF EXISTS Arret_Metro ;
CREATE TABLE Arret_Metro (
id_arret_metro INTEGER NOT NULL UNIQUE,
nom_arret_metro VARCHAR,
PRIMARY KEY (id_arret_metro)
); 

DROP TABLE IF EXISTS Niveau_competition ;
CREATE TABLE Niveau_competition (
id_niveau INTEGER NOT NULL UNIQUE,
nom_niveau VARCHAR, 
PRIMARY KEY (id_niveau)
); 

DROP TABLE IF EXISTS Participer ;
CREATE TABLE Participer (
id_discipline INTEGER NOT NULL REFERENCES Discipline, 
code_pays VARCHAR(3) REFERENCES Pays, 
PRIMARY KEY (id_discipline,  code_pays)
); 

DROP TABLE IF EXISTS Sepasser ; 
CREATE TABLE Sepasser (
id_site INTEGER NOT NULL REFERENCES Site, 
id_epreuve INTEGER NOT NULL REFERENCES Epreuve, 
id_niveau INTEGER NOT NULL REFERENCES Niveau_competition, 
date_epreuve DATE,
heure_epreuve_debut TIME,
heure_epreuve_fin TIME,
PRIMARY KEY (id_site,  id_epreuve,  id_niveau, date_epreuve, heure_epreuve_debut)
);

DROP TABLE IF EXISTS PrendreBus ; 
CREATE TABLE PrendreBus (
id_site INTEGER NOT NULL REFERENCES Site,
id_arret_bus INTEGER NOT NULL REFERENCES Arret_Bus,
distance_arret_bus INTEGER, 
PRIMARY KEY (id_site,  id_arret_bus)
); 

DROP TABLE IF EXISTS PrendreTrain ; 
CREATE TABLE PrendreTrain (
id_site INTEGER NOT NULL REFERENCES Site, 
id_gare INTEGER NOT NULL REFERENCES Gare, 
distance_gare_site INTEGER, 
PRIMARY KEY (id_site,  id_gare)
);

DROP TABLE IF EXISTS PrendreMetro ;
CREATE TABLE PrendreMetro (
id_site INTEGER NOT NULL REFERENCES Site,
id_arret_metro INTEGER NOT NULL REFERENCES Arret_Metro, 
distance_metro_site INTEGER, 
PRIMARY KEY (id_site,  id_arret_metro)
);

DROP TABLE IF EXISTS Jouer ;
CREATE TABLE Jouer (
id_athlete INTEGER NOT NULL REFERENCES Athlete,
id_epreuve INTEGER NOT NULL REFERENCES Epreuve,
PRIMARY KEY (id_athlete,  id_epreuve)
); 

ALTER TABLE Athlete ADD CONSTRAINT pays_cont FOREIGN KEY (pays_code) REFERENCES Pays(code_pays) ON DELETE CASCADE;
ALTER TABLE Athlete ADD CONSTRAINT coach_cont FOREIGN KEY (id_coach) REFERENCES Coach(id_coach) ON DELETE CASCADE;
ALTER TABLE Epreuve ADD CONSTRAINT dis_cont FOREIGN KEY (id_discipline) REFERENCES Discipline(id_discipline) ON DELETE CASCADE;
ALTER TABLE Epreuve ADD CONSTRAINT cat_cont FOREIGN KEY (id_categorie) REFERENCES Categorie(id_categorie) ON DELETE CASCADE;
ALTER TABLE Record ADD CONSTRAINT ath_cont_record FOREIGN KEY (detenteur_record) REFERENCES Athlete(id_athlete) ON DELETE CASCADE;
ALTER TABLE Record ADD CONSTRAINT ath_cont_olym FOREIGN KEY (detenteur_du_dernier_titre_olympique) REFERENCES Athlete(id_athlete) ON DELETE CASCADE;
ALTER TABLE Record ADD CONSTRAINT epreuve_cont FOREIGN KEY (id_epreuve) REFERENCES Epreuve(id_epreuve) ON DELETE CASCADE;
ALTER TABLE Participer ADD CONSTRAINT pays2_cont FOREIGN KEY (code_pays) REFERENCES Pays(code_pays) ON DELETE CASCADE;
ALTER TABLE Participer ADD CONSTRAINT dis2_cont FOREIGN KEY (id_discipline) REFERENCES Discipline(id_discipline) ON DELETE CASCADE;
ALTER TABLE Sepasser ADD CONSTRAINT site_cont FOREIGN KEY (id_site) REFERENCES Site(id_site) ON DELETE CASCADE;
ALTER TABLE Sepasser ADD CONSTRAINT epreuve2_cont FOREIGN KEY (id_epreuve) REFERENCES Epreuve(id_epreuve) ON DELETE CASCADE;
ALTER TABLE Sepasser ADD CONSTRAINT niv_cont FOREIGN KEY (id_niveau) REFERENCES Niveau_competition(id_niveau) ON DELETE CASCADE;
ALTER TABLE PrendreBus ADD CONSTRAINT site_bus_cont FOREIGN KEY (id_site) REFERENCES Site(id_site) ON DELETE CASCADE;
ALTER TABLE PrendreBus ADD CONSTRAINT bus_cont FOREIGN KEY (id_arret_bus) REFERENCES Arret_Bus(id_arret_bus) ON DELETE CASCADE;
ALTER TABLE PrendreTrain ADD CONSTRAINT site_train_cont FOREIGN KEY (id_site) REFERENCES Site(id_site) ON DELETE CASCADE;
ALTER TABLE PrendreTrain ADD CONSTRAINT train_cont FOREIGN KEY (id_gare) REFERENCES Gare(id_gare) ON DELETE CASCADE;
ALTER TABLE PrendreMetro ADD CONSTRAINT site_metro_cont FOREIGN KEY (id_site) REFERENCES Site(id_site) ON DELETE CASCADE;
ALTER TABLE PrendreMetro ADD CONSTRAINT metro_cont FOREIGN KEY (id_arret_metro) REFERENCES Arret_Metro(id_arret_metro) ON DELETE CASCADE;
ALTER TABLE Jouer ADD CONSTRAINT ath_joue_cont FOREIGN KEY (id_athlete) REFERENCES Athlete(id_athlete) ON DELETE CASCADE;
ALTER TABLE Jouer ADD CONSTRAINT epreuve_joue_cont FOREIGN KEY (id_epreuve) REFERENCES Epreuve(id_epreuve) ON DELETE CASCADE;

ALTER TABLE Athlete ADD CONSTRAINT pays_cont FOREIGN KEY (pays_code) REFERENCES Pays(code_pays) ON UPDATE CASCADE;
ALTER TABLE Athlete ADD CONSTRAINT coach_cont FOREIGN KEY (id_coach) REFERENCES Coach(id_coach) ON UPDATE CASCADE;
ALTER TABLE Epreuve ADD CONSTRAINT dis_cont FOREIGN KEY (id_discipline) REFERENCES Discipline(id_discipline) ON UPDATE CASCADE;
ALTER TABLE Epreuve ADD CONSTRAINT cat_cont FOREIGN KEY (id_categorie) REFERENCES Categorie(id_categorie) ON UPDATE CASCADE;
ALTER TABLE Record ADD CONSTRAINT ath_cont_record FOREIGN KEY (detenteur_record) REFERENCES Athlete(id_athlete) ON UPDATE CASCADE;
ALTER TABLE Record ADD CONSTRAINT ath_cont_olym FOREIGN KEY (detenteur_du_dernier_titre_olympique) REFERENCES Athlete(id_athlete) ON UPDATE CASCADE;
ALTER TABLE Record ADD CONSTRAINT epreuve_cont FOREIGN KEY (id_epreuve) REFERENCES Epreuve(id_epreuve) ON UPDATE CASCADE;
ALTER TABLE Participer ADD CONSTRAINT pays2_cont FOREIGN KEY (code_pays) REFERENCES Pays(code_pays) ON UPDATE CASCADE;
ALTER TABLE Participer ADD CONSTRAINT dis2_cont FOREIGN KEY (id_discipline) REFERENCES Discipline(id_discipline) ON UPDATE CASCADE;
ALTER TABLE Sepasser ADD CONSTRAINT site_cont FOREIGN KEY (id_site) REFERENCES Site(id_site) ON UPDATE CASCADE;
ALTER TABLE Sepasser ADD CONSTRAINT epreuve2_cont FOREIGN KEY (id_epreuve) REFERENCES Epreuve(id_epreuve) ON UPDATE CASCADE;
ALTER TABLE Sepasser ADD CONSTRAINT niv_cont FOREIGN KEY (id_niveau) REFERENCES Niveau_competition(id_niveau) ON UPDATE CASCADE;
ALTER TABLE PrendreBus ADD CONSTRAINT site_bus_cont FOREIGN KEY (id_site) REFERENCES Site(id_site) ON UPDATE CASCADE;
ALTER TABLE PrendreBus ADD CONSTRAINT bus_cont FOREIGN KEY (id_arret_bus) REFERENCES Arret_Bus(id_arret_bus) ON UPDATE CASCADE;
ALTER TABLE PrendreTrain ADD CONSTRAINT site_train_cont FOREIGN KEY (id_site) REFERENCES Site(id_site) ON UPDATE CASCADE;
ALTER TABLE PrendreTrain ADD CONSTRAINT train_cont FOREIGN KEY (id_gare) REFERENCES Gare(id_gare) ON UPDATE CASCADE;
ALTER TABLE PrendreMetro ADD CONSTRAINT site_metro_cont FOREIGN KEY (id_site) REFERENCES Site(id_site) ON UPDATE CASCADE;
ALTER TABLE PrendreMetro ADD CONSTRAINT metro_cont FOREIGN KEY (id_arret_metro) REFERENCES Arret_Metro(id_arret_metro) ON UPDATE CASCADE;
ALTER TABLE Jouer ADD CONSTRAINT ath_joue_cont FOREIGN KEY (id_athlete) REFERENCES Athlete(id_athlete) ON UPDATE CASCADE;
ALTER TABLE Jouer ADD CONSTRAINT epreuve_joue_cont FOREIGN KEY (id_epreuve) REFERENCES Epreuve(id_epreuve) ON UPDATE CASCADE;