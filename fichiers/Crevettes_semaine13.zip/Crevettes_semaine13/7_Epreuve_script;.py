import requests
from bs4 import BeautifulSoup
import psycopg2

def scrape_and_insert_data(url, column_index, compt):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[0].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")   
                if len(columns) > column_index:
                    epreuve= columns[column_index].text.strip()
                    if epreuve=="4 × 100 m" or epreuve=="4 × 400 m":
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,1,0))
                        conn.commit()
                        compt+=1
                    else:
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,0,0))
                        conn.commit()
                        compt+=1
                compt_ligne+=1
                
        rows = sports_table[1].find_all("tr")
        compt_ligne=0
    
        for row in rows:
                columns = row.find_all("td")
                if len(columns) > column_index:
                    epreuve= columns[column_index].text.strip()
                    if epreuve=="4 × 100 m" or epreuve=="4 × 400 m":
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,5,0))
                        conn.commit()
                        compt+=1
                    else:
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,4,0))
                        conn.commit()
                        compt+=1
                compt_ligne+=1
        
        rows = sports_table[2].find_all("tr")
        compt_ligne=0
        for row in rows:
                columns = row.find_all("td")
                    
                if len(columns) > column_index:
                    epreuve= columns[column_index].text.strip()
                    cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,9,0))
                    conn.commit()
                    compt+=1
                compt_ligne+=1
        return compt
    
def scrape_and_insert_data_avi(url, column_index, compt, indice):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[1].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")
                    
                if len(columns) > column_index and compt_ligne>=2:
                    epreuve= columns[column_index].text.strip()
                    if len(epreuve)>0:
                        if epreuve[0]=="D":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,indice+2,1))
                            conn.commit()
                            compt+=1
                        elif epreuve[0]=="Q":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,indice+3,1))
                            conn.commit()
                            compt+=1
                        elif epreuve[0]=="H":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,indice+1,1))
                            conn.commit()
                            compt+=1
                        else:
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,indice,1))
                            conn.commit()
                            compt+=1
                compt_ligne+=1
        return compt
    
def scrape_and_insert_data_bad(url, column_index, compt,nb_tab,indice,id_dis):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_tab].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")
                if len(columns) > column_index and compt_ligne>=indice:
                    epreuve= columns[column_index].text.strip()
                    if epreuve[0]=="D":
                        if epreuve=="Double mixte":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,10,id_dis))
                            conn.commit()
                            compt+=1
                        elif epreuve[7]=="h" or epreuve[7]=="m":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,6,id_dis))
                            conn.commit()
                            compt+=1
                        elif epreuve[7]=="d":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,2,id_dis))
                            conn.commit()
                            compt+=1
                    else:
                        if epreuve[7]=="h" or epreuve[7]=="m":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,4,id_dis))
                            conn.commit()
                            compt+=1
                        if epreuve[7]=="d":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,0,id_dis))
                            conn.commit()
                            compt+=1
                compt_ligne+=1
        return compt
    
def scrape_and_insert_data_sport_co(liste_sports,liste_index,compt):
    for i in range(0,len(liste_sports)):
        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,liste_sports[i],1,liste_index[i]))
        conn.commit()
        compt+=1
        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,liste_sports[i],5,liste_index[i]))
        conn.commit()
        compt+=1
    return compt

def scrape_and_insert_sport_poid(indice_dep,indice_fin,sport,compt,ind):
    for i in range(indice_dep,indice_fin+1):
        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,sport,i,ind))
        conn.commit()
        compt+=1
    return compt

def scrape_and_insert_data_gene(url, column_index, compt,nb_table,nb_ligne,id_cat,id_dis,balise):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_table].find_all(balise)
        compt_ligne=0

        for row in rows:
                columns = row.find_all("th")
                if len(columns) > column_index and compt_ligne>=nb_ligne:
                    epreuve= columns[column_index].text.strip()
                    if compt_ligne==2:
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+4,id_dis))
                        conn.commit()
                        compt+=1
                    else:
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
                        conn.commit()
                        compt+=1
                compt_ligne+=1
        return compt
    
def scrape_and_insert_data_ligne(url, column_index, compt,nb_table,nb_ligne,arret,id_dis,id_cat):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_table].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")
                if len(columns) > column_index and compt_ligne>=nb_ligne and compt_ligne<arret:
                    epreuve= columns[column_index].text.strip()
                    if len(epreuve)>=2:
                        if epreuve[1]=="1" or epreuve[2]=="1":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
                            conn.commit()
                            compt+=1
                        elif epreuve[1]=="2":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+2,id_dis))
                            conn.commit()
                            compt+=1
                        elif epreuve[1]=="4":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+3,id_dis))
                            conn.commit()
                            compt+=1
                compt_ligne+=1
        return compt
    
def scrape_and_insert_data_BMX(url, column_index, compt,nb_table,nb_ligne,arret,id_dis,id_cat):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_table].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td") 
                if len(columns) > column_index and compt_ligne>=nb_ligne and compt_ligne<arret: 
                    epreuve= columns[column_index].text.strip()
                    if epreuve[0]=="B":
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
                        conn.commit()
                        compt+=1
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+4,id_dis))
                        conn.commit()
                        compt+=1
                compt_ligne+=1
        return compt
    
def script_une_epreuve(epreuve,id_cat,id_dis,compt):
    cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
    conn.commit()
    compt+=1
    cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+4,id_dis))
    conn.commit()
    compt+=1
    return compt
    
def scrape_and_insert_data_piste(url, column_index, compt,nb_table,nb_ligne,arret,id_dis,id_cat):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_table].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")     
                if len(columns) > column_index and compt_ligne>=nb_ligne and compt_ligne<arret:
                    epreuve= columns[column_index].text.strip()
                    if len(epreuve)>=2:
                        if epreuve[-1]=="s":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+1,id_dis))
                            conn.commit()
                            compt+=1
                        elif epreuve[0]=="C":
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+2,id_dis))
                            conn.commit()
                            compt+=1
                        else:
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
                            conn.commit()
                            compt+=1
                compt_ligne+=1
        return compt

def scrape_and_insert_data_equi(url, column_index, compt,nb_table,nb_ligne,arret,id_dis,id_cat):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_table].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")
                if len(columns) > column_index and compt_ligne>=nb_ligne and compt_ligne<arret:
                    epreuve= columns[column_index].text.strip()
                    cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
                    conn.commit()
                    compt+=1
                    cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+1,id_dis))
                    conn.commit()
                    compt+=1
                compt_ligne+=1
        return compt
    
def scrape_and_insert_data_escrime(url, column_index, compt,nb_table,nb_ligne,arret,id_dis,id_cat):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_table].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")
                if len(columns) > column_index and compt_ligne>=nb_ligne and compt_ligne<arret:
                    epreuve= columns[column_index].text.strip()
                    if len(epreuve)<8:
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
                        conn.commit()
                        compt+=1
                        cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+1,id_dis))
                        conn.commit()
                        compt+=1
                compt_ligne+=1
        return compt
    
def scrape_and_insert_data_gym(url, column_index, compt,nb_table,nb_ligne,arret,id_dis,id_cat):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_table].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")   
                if len(columns) > column_index and compt_ligne>=nb_ligne and compt_ligne<arret: 
                    epreuve= columns[column_index].text.strip()
                    if len(epreuve)>=2:
                        if len(epreuve)>=28:
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat+1,id_dis))
                            conn.commit()
                            compt+=1
                        else:
                            cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
                            conn.commit()
                            compt+=1
                compt_ligne+=1
        return compt

def scrape_and_insert_data_nat(url, column_index, compt,nb_table,nb_ligne,arret,id_dis,id_cat):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")

    sports_table = soup.find_all("table", class_="wikitable")

    if sports_table:
        rows = sports_table[nb_table].find_all("tr")
        compt_ligne=0

        for row in rows:
                columns = row.find_all("td")
                if len(columns) > column_index and compt_ligne>=nb_ligne and compt_ligne<arret:
                    epreuve= columns[column_index].text.strip()
                    cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,epreuve,id_cat,id_dis))
                    conn.commit()
                    compt+=1
                compt_ligne+=1
        return compt

conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)


cur = conn.cursor()
cur.execute("Truncate Epreuve CASCADE;")

url_athle="https://fr.wikipedia.org/wiki/Athl%C3%A9tisme_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_avi="https://fr.wikipedia.org/wiki/Aviron_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_bad="https://fr.wikipedia.org/wiki/Badminton_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_break="https://fr.wikipedia.org/wiki/Breakdance_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_kayak="https://fr.wikipedia.org/wiki/Cano%C3%AB-kayak_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_bmx="https://fr.wikipedia.org/wiki/BMX_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_sur_piste="https://fr.wikipedia.org/wiki/Cyclisme_sur_piste_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_equi="https://fr.wikipedia.org/wiki/%C3%89quitation_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_escrime="https://fr.wikipedia.org/wiki/Escrime_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_gym="https://fr.wikipedia.org/wiki/Gymnastique_artistique_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_nat="https://fr.wikipedia.org/wiki/Natation_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_nat_art="https://fr.wikipedia.org/wiki/Natation_artistique_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_plon="https://fr.wikipedia.org/wiki/Plongeon_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_tennis="https://fr.wikipedia.org/wiki/Tennis_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_tennis_table="https://fr.wikipedia.org/wiki/Tennis_de_table_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_tir="https://fr.wikipedia.org/wiki/Tir_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_voile="https://fr.wikipedia.org/wiki/Voile_aux_Jeux_olympiques_d%27%C3%A9t%C3%A9_de_2024"
url_bocca="https://fr.wikipedia.org/wiki/Boccia_aux_Jeux_paralympiques_d%27%C3%A9t%C3%A9_de_2024"
url_es_h="https://fr.wikipedia.org/wiki/Escrime_aux_Jeux_paralympiques_d%27%C3%A9t%C3%A9_de_2024"
url_aviron_h="https://fr.wikipedia.org/wiki/Aviron_aux_Jeux_paralympiques_d%27%C3%A9t%C3%A9_de_2024"
compt=0

compt=scrape_and_insert_data(url_athle,0,compt)
compt=scrape_and_insert_data_avi(url_avi,0,compt,0)
compt=scrape_and_insert_data_avi(url_avi,0,compt,4)
compt=scrape_and_insert_data_bad(url_bad,0,compt,1,2,2)
compt=scrape_and_insert_data_sport_co(["Basket-ball à 5","Basket-ball à 3","Handball","Football","Hockey sur gazon","Waterpolo","Rugby à sept","Volley Ball","Beach Volley","Basket Fauteuil","Football à 5","Rugby fauteuil","Volley assis","Goalball"],[5,6,24,18,25,33,35,44,45,47,50,66,68,51],compt)
compt=scrape_and_insert_sport_poid(12,18,"Boxe",compt,7)
compt=scrape_and_insert_sport_poid(19,24,"Boxe",compt,7)
compt=scrape_and_insert_sport_poid(40,43,"Taekwondo",compt,38)
compt=scrape_and_insert_sport_poid(44,47,"Taekwondo",compt,38)
compt=scrape_and_insert_sport_poid(25,29,"Haltérophilie",compt,23)
compt=scrape_and_insert_sport_poid(44,44,"Haltérophilie",compt,23)
compt=scrape_and_insert_sport_poid(30,33,"Haltérophilie",compt,23)
compt=scrape_and_insert_sport_poid(13,13,"Lutte",compt,28)
compt=scrape_and_insert_sport_poid(61,65,"Lutte",compt,28)
compt=scrape_and_insert_sport_poid(19,19,"Lutte",compt,28)
compt=scrape_and_insert_sport_poid(66,69,"Lutte",compt,28)
compt=scrape_and_insert_sport_poid(48,53,"Judo",compt,26)
compt=scrape_and_insert_sport_poid(26,26,"Judo",compt,26)
compt=scrape_and_insert_sport_poid(54,60,"Judo",compt,26)
compt=scrape_and_insert_data_gene(url_break, 0, compt,2,1,0,8,"tr")
compt=scrape_and_insert_data_ligne(url_kayak, 1, compt,3,0,5,9,4)
compt=scrape_and_insert_data_ligne(url_kayak, 0, compt,3,1,6,9,4)
compt=scrape_and_insert_data_ligne(url_kayak, 1, compt,3,6,8,9,0)
compt=scrape_and_insert_data_ligne(url_kayak, 0, compt,3,7,12,9,0)
compt=scrape_and_insert_data_ligne(url_kayak, 1, compt,2,1,4,10,4)
compt=scrape_and_insert_data_ligne(url_kayak, 0, compt,2,2,4,10,4)
compt=scrape_and_insert_data_ligne(url_kayak, 1, compt,2,4,5,10,0)
compt=scrape_and_insert_data_ligne(url_kayak, 0, compt,2,5,7,10,0)
compt=scrape_and_insert_data_BMX(url_bmx, 0, compt,2,1,6,11,0)
compt=script_une_epreuve("VTT",0,12,compt)
compt=scrape_and_insert_data_piste(url_sur_piste, 1, compt,0,1,2,13,4)
compt=scrape_and_insert_data_piste(url_sur_piste, 0, compt,0,2,7,13,4)
compt=scrape_and_insert_data_piste(url_sur_piste, 1, compt,0,7,8,13,0)
compt=scrape_and_insert_data_piste(url_sur_piste, 0, compt,0,8,13,13,0)
compt=script_une_epreuve("Course en ligne",0,14,compt)
compt=script_une_epreuve("Course contre la montre",0,14,compt)
compt=scrape_and_insert_data_equi(url_equi, 0, compt,0,1,4,15,8)
compt=script_une_epreuve("Combiné",0,16,compt)
compt=script_une_epreuve("Vitesse",0,16,compt)
compt=scrape_and_insert_data_escrime(url_escrime, 1, compt,0,1,3,17,4)
compt=scrape_and_insert_data_escrime(url_escrime, 0, compt,0,3,7,17,4)
compt=scrape_and_insert_data_escrime(url_escrime, 1, compt,0,1,3,17,0)
compt=scrape_and_insert_data_escrime(url_escrime, 0, compt,0,3,7,17,0)
compt=script_une_epreuve("Golf",0,18,compt)
compt=scrape_and_insert_data_gym(url_gym, 1, compt,0,2,3,19,4)
compt=scrape_and_insert_data_gym(url_gym, 0, compt,0,3,10,19,4)
compt=scrape_and_insert_data_gym(url_gym, 1, compt,0,10,11,19,0)
compt=scrape_and_insert_data_gym(url_gym, 0, compt,0,11,16,19,0)
cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,"Gym rithmique",0,20))
conn.commit()
compt+=1
cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,"Gym rithmique",1,20))
conn.commit()
compt+=1
compt=scrape_and_insert_data_nat(url_nat, 1, compt,1,0,4,29,0)
compt=scrape_and_insert_data_nat(url_nat, 0, compt,1,4,21,29,0)
compt=scrape_and_insert_data_nat(url_nat, 1, compt,1,21,22,29,4)
compt=scrape_and_insert_data_nat(url_nat, 0, compt,1,22,39,29,4)
compt=scrape_and_insert_data_nat(url_nat, 1, compt,1,39,40,29,8)
compt=scrape_and_insert_data_nat(url_nat_art, 3, compt,0,0,4,30,9)
compt=scrape_and_insert_data_nat(url_nat_art, 3, compt,0,4,7,30,10)
compt=script_une_epreuve("Natation marathon",0,31,compt)
compt=scrape_and_insert_data_nat(url_plon, 1, compt,0,0,2,32,4)
compt=scrape_and_insert_data_nat(url_plon, 0, compt,0,2,5,32,4)
compt=scrape_and_insert_data_nat(url_plon, 1, compt,0,5,6,32,0)
compt=scrape_and_insert_data_nat(url_plon, 0, compt,0,6,9,32,0)
compt=script_une_epreuve("Pentathlon moderne",0,34,compt)
compt=script_une_epreuve("Skateboard park",0,36,compt)
compt=script_une_epreuve("Skateboard street",0,36,compt)
compt=script_une_epreuve("Shortboard",0,37,compt)
compt=scrape_and_insert_data_bad(url_tennis,0,compt,2,1,39)
compt=scrape_and_insert_data_bad(url_tennis_table,0,compt,0,1,40)
compt=script_une_epreuve("Tir à l'arc",0,41,compt)
compt=script_une_epreuve("Tir à l'arc",1,41,compt)
cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,"Tir à l'arc",9,41))
conn.commit()
compt+=1
compt=scrape_and_insert_data_nat(url_tir, 2, compt,0,0,3,42,0)
compt=scrape_and_insert_data_nat(url_tir, 1, compt,0,3,4,42,0)
compt=scrape_and_insert_data_nat(url_tir, 2, compt,0,4,5,42,0)
compt=scrape_and_insert_data_nat(url_tir, 1, compt,0,5,6,42,0)
compt=scrape_and_insert_data_nat(url_tir, 2, compt,0,6,7,42,0)
compt=scrape_and_insert_data_nat(url_tir, 0, compt,0,7,8,42,0)

compt=scrape_and_insert_data_nat(url_tir, 2, compt,0,0,3,42,4)
compt=scrape_and_insert_data_nat(url_tir, 1, compt,0,3,4,42,4)
compt=scrape_and_insert_data_nat(url_tir, 2, compt,0,4,5,42,4)
compt=scrape_and_insert_data_nat(url_tir, 1, compt,0,5,6,42,4)
compt=scrape_and_insert_data_nat(url_tir, 2, compt,0,6,7,42,4)
compt=scrape_and_insert_data_nat(url_tir, 0, compt,0,7,8,42,4)
compt=script_une_epreuve("Triathlon",0,43,compt)
cur.execute("INSERT INTO Epreuve(id_epreuve,nom_epreuve,id_categorie,id_discipline) VALUES (%s,%s,%s,%s)", (compt,"Triathlon relais par équipe",9,43))
conn.commit()
compt+=1
compt=scrape_and_insert_data_nat(url_voile, 1, compt,1,2,3,46,4)
compt=scrape_and_insert_data_nat(url_voile, 0, compt,1,3,6,46,4)
compt=scrape_and_insert_data_nat(url_voile, 1, compt,1,6,7,46,0)
compt=scrape_and_insert_data_nat(url_voile, 0, compt,1,7,10,46,0)
compt=scrape_and_insert_data_nat(url_voile, 1, compt,1,10,11,46,9)
compt=scrape_and_insert_data_nat(url_voile, 0, compt,1,11,12,46,9)
compt=scrape_and_insert_data_nat(url_bocca, 1, compt,1,2,3,48,4)
compt=scrape_and_insert_data_nat(url_bocca, 0, compt,1,3,6,48,4)
compt=scrape_and_insert_data_nat(url_bocca, 1, compt,1,6,7,48,0)
compt=scrape_and_insert_data_nat(url_bocca, 0, compt,1,7,10,48,0)
compt=scrape_and_insert_data_nat(url_bocca, 1, compt,1,10,11,48,9)
compt=scrape_and_insert_data_nat(url_bocca, 0, compt,1,11,14,48,10)
compt=scrape_and_insert_data_escrime(url_es_h, 1, compt,0,2,3,49,0)
compt=scrape_and_insert_data_escrime(url_es_h, 0, compt,0,3,9,49,0)
compt=scrape_and_insert_data_escrime(url_es_h, 1, compt,0,10,11,49,4)
compt=scrape_and_insert_data_escrime(url_es_h, 0, compt,0,11,20,49,4)

cur.close()
conn.close()