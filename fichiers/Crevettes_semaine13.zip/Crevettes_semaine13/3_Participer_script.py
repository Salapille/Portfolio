import requests
from bs4 import BeautifulSoup
import psycopg2
from random import randint

CODE_PAYS = ['AD', 'AE', 'AF', 'AG', 'AI', 'AL', 'AM', 'AO', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AW', 'AX',
              'AZ', 'BA', 'BB', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ', 'BL', 'BM', 'BN', 'BO', 'BQ',
              'BR', 'BS', 'BT', 'BV', 'BW', 'BY', 'BZ', 'CA', 'CC', 'CD', 'CF', 'CG', 'CH', 'CI', 'CK',
              'CL', 'CM', 'CN', 'CO', 'CR', 'CU', 'CV', 'CW', 'CX', 'CY', 'CZ', 'DE', 'DJ', 'DK', 'DM',
              'DO', 'DZ', 'EC', 'EE', 'EG', 'EH', 'ER', 'ES', 'ET', 'FI', 'FJ', 'FK', 'FM', 'FO', 'FR',
              'GA', 'GB', 'GD', 'GE', 'GF', 'GG', 'GH', 'GI', 'GL', 'GM', 'GN', 'GP', 'GQ', 'GR', 'GS',
              'GT', 'GU', 'GW', 'GY', 'HK', 'HM', 'HN', 'HR', 'HT', 'HU', 'ID', 'IE', 'IL', 'IM', 'IN',
              'IO', 'IQ', 'IR', 'IS', 'IT', 'JE', 'JM', 'JO', 'JP', 'KE', 'KG', 'KH', 'KI', 'KM', 'KN',
              'KP', 'KR', 'XK', 'KW', 'KY', 'KZ', 'LA', 'LB', 'LC', 'LI', 'LK', 'LR', 'LS', 'LT', 'LU',
              'LV', 'LY', 'MA', 'MC', 'MD', 'ME', 'MF', 'MG', 'MH', 'MK', 'ML', 'MM', 'MN', 'MO', 'MP',
              'MQ', 'MR', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY', 'MZ', 'NA', 'NC', 'NE', 'NF', 'NG',
              'NI', 'NL', 'NO', 'NP', 'NR', 'NU', 'NZ', 'OM', 'PA', 'PE', 'PF', 'PG', 'PH', 'PK', 'PL',
              'PM', 'PN', 'PR', 'PS', 'PT', 'PW', 'PY', 'QA', 'RE', 'RO', 'RS', 'RU', 'RW', 'SA', 'SB',
              'SC', 'SD', 'SS', 'SE', 'SG', 'SH', 'SI', 'SJ', 'SK', 'SL', 'SM', 'SN', 'SO', 'SR', 'ST',
              'SV', 'SX', 'SY', 'SZ', 'TC', 'TD', 'TF', 'TG', 'TH', 'TJ', 'TK', 'TL', 'TM', 'TN', 'TO',
              'TR', 'TT', 'TV', 'TW', 'TZ', 'UA', 'UG', 'UM', 'US', 'UY', 'UZ', 'VA', 'VC', 'VE', 'VG',
              'VI', 'VN', 'VU', 'WF', 'WS', 'YE', 'YT', 'ZA', 'ZM', 'ZW', 'CS', 'AN']

def generer_sport_co(liste_sport,nb):
    for i in range(0,len(liste_sport)):
        l_pays=[]
        cur.execute("INSERT INTO Participer VALUES (%s,%s)", (liste_sport[i],CODE_PAYS[74]))
        conn.commit()
        l_pays.append(CODE_PAYS[74])
        for j in range(nb):
            code=randint(0,len(CODE_PAYS)-1)
            while CODE_PAYS[code] in l_pays:
                code=randint(0,len(CODE_PAYS)-1)
            cur.execute("INSERT INTO Participer VALUES (%s,%s)", (liste_sport[i],CODE_PAYS[code]))
            conn.commit()
            l_pays.append(CODE_PAYS[code])
            
def generer_sport(liste_sport_exclu,mini,maxi):
    for i in range(0,69):
        if i not in liste_sport_exclu:
            l_pays=[]
            cur.execute("INSERT INTO Participer VALUES (%s,%s)", (i,CODE_PAYS[74]))
            conn.commit()
            l_pays.append(CODE_PAYS[74])
            nb=randint(mini,maxi)
            for j in range(nb):
                code=randint(0,len(CODE_PAYS)-1)
                while CODE_PAYS[code] in l_pays:
                    code=randint(0,len(CODE_PAYS)-1)
                cur.execute("INSERT INTO Participer VALUES (%s,%s)", (i,CODE_PAYS[code]))
                conn.commit()
                l_pays.append(CODE_PAYS[code])
    


conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host="localhost"
)

cur = conn.cursor()
cur.execute("Truncate Participer CASCADE;")

generer_sport_co([5,6,24,25,18,33,35,44,45,47,50,51,68,66],32)
generer_sport([5,6,24,25,18,33,35,44,45,47,50,51,68,66],8,20)

cur.close()
conn.close()