import os
import subprocess

def execute_python_files(folder_path):
    # Parcours de tous les fichiers dans le dossier
    for filename in os.listdir(folder_path):
        if filename.endswith(".py") and filename != "Remplir_BD.py":  # Vérifie si le fichier est un fichier Python et exclut "Remplir_BD.py"
            filepath = os.path.join(folder_path, filename)
            print(f"Exécution du script Python : {filepath}")
            try:
                # Exécute le script Python
                subprocess.run(["python", filepath], check=True)
                print("Exécution terminée avec succès.")
            except subprocess.CalledProcessError as e:
                print(f"Erreur lors de l'exécution du script : {e}")
            print()  # Ajoute une ligne vide entre chaque script

# Chemin du dossier contenant les scripts Python à exécuter
folder_path = r"C:\Users\Manon\Desktop\Crevettes_semaine12"

# Exécute les scripts Python dans le dossier spécifié
execute_python_files(folder_path)