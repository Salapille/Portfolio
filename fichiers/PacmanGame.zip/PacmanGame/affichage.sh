affichage=("
   \e[1;33m╔════════════════════════════════════════════════════╗\e[0m"
    "   \e[1;33m║ ╔════════════════════════════════════════════════╗ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m ____  _                                       \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m| __ )(_) ___ _ ____   _____ _ __  _   _  ___  \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m|  _ \| |/ _ \ '_ \ \ / / _ \ '_ \| | | |/ _ \ \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m| |_) | |  __/ | | \ V /  __/ | | | |_| |  __/ \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m|____/|_|\___|_| |_|\_/ \___|_| |_|\__,_|\___| \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║           \e[0;37mChoisissez la difficulté :           \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║        \e[0;42m 1 : Facile    \e[0m  \e[0;44m 2 : Normale  \e[0m         \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║        \e[0;43m 3 : Difficile \e[0m  \e[0;41m 4 : Hardcore \e[0m         \e[1;33m║ ║\e[0m"
	"   \e[1;33m║ ║              \e[0;46m 5 : retour au menu \e[0m              \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ╚════════════════════════════════════════════════╝ ║\e[0m"
    "   \e[1;33m╚════════════════════════════════════════════════════╝\e[0m"
)

affichage2=("
   \e[1;33m╔════════════════════════════════════════════════════╗\e[0m"
    "   \e[1;33m║ ╔════════════════════════════════════════════════╗ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m ____  _                                       \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m| __ )(_) ___ _ ____   _____ _ __  _   _  ___  \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m|  _ \| |/ _ \ '_ \ \ / / _ \ '_ \| | | |/ _ \ \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m| |_) | |  __/ | | \ V /  __/ | | | |_| |  __/ \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m|____/|_|\___|_| |_|\_/ \___|_| |_|\__,_|\___| \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║              \e[0;37mChoisissez la carte :             \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║        \e[0;42m 1 : classique \e[0m  \e[0;44m 2 : en longueur \e[0m      \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║        \e[0;43m 3 : totem     \e[0m  \e[0;41m 4 : forteresse  \e[0m      \e[1;33m║ ║\e[0m"
	"   \e[1;33m║ ║              \e[0;46m 5 : retour au menu \e[0m              \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ╚════════════════════════════════════════════════╝ ║\e[0m"
    "   \e[1;33m╚════════════════════════════════════════════════════╝\e[0m"
)
affichage3=("
   \e[1;33m╔════════════════════════════════════════════════════╗\e[0m"
    "   \e[1;33m║ ╔════════════════════════════════════════════════╗ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m ____  _                                       \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m| __ )(_) ___ _ ____   _____ _ __  _   _  ___  \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m|  _ \| |/ _ \ '_ \ \ / / _ \ '_ \| | | |/ _ \ \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m| |_) | |  __/ | | \ V /  __/ | | | |_| |  __/ \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m|____/|_|\___|_| |_|\_/ \___|_| |_|\__,_|\___| \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
	"   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║           \e[0;37mChoisissez vos préférences :         \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║  \e[0;42m 1 : choix manuels   \e[0m  \e[0;44m 2 : choix aléatoires \e[0m \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║  \e[0;43m 3 : carte aléatoire \e[0m  \e[0;41m 4 : difficulté aléa. \e[0m \e[1;33m║ ║\e[0m"
	"   \e[1;33m║ ║              \e[0;46m 5 : retour au menu \e[0m              \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ╚════════════════════════════════════════════════╝ ║\e[0m"
    "   \e[1;33m╚════════════════════════════════════════════════════╝\e[0m"
)
affichage4=("
   \e[1;33m╔════════════════════════════════════════════════════╗\e[0m"
    "   \e[1;33m║ ╔════════════════════════════════════════════════╗ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m ____  _                                       \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m| __ )(_) ___ _ ____   _____ _ __  _   _  ___  \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m|  _ \| |/ _ \ '_ \ \ / / _ \ '_ \| | | |/ _ \ \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m| |_) | |  __/ | | \ V /  __/ | | | |_| |  __/ \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║ \e[0;36m|____/|_|\___|_| |_|\_/ \___|_| |_|\__,_|\___| \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║           \e[0;37mChoisissez vos préférences :         \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ║   \e[0;42m 1 : votre carte \e[0m  \e[0;44m 2 : cartes existantes \e[0m   \e[1;33m║ ║\e[0m"
    "   \e[1;33m║ ║                                                ║ ║\e[0m"
	"   \e[1;33m║ ║                                                ║ ║\e[0m"
    "   \e[1;33m║ ╚════════════════════════════════════════════════╝ ║\e[0m"
    "   \e[1;33m╚════════════════════════════════════════════════════╝\e[0m"
)

# Lit le fichier texte et le transforme en carte.
# permet de transformer le fichier texte en carte utilisable pour l'utilisateur
# permet aussi d'initialiser les coordonnées de base de Pacman et des fantômes
# Fait par Noé
function lecture_map(){ 
    while IFS= read -r line; do
        local row=""
        for (( i=0; i<${#line}; i++ )); do
            char="${line:$i:1}"
            if [[ "$char" == "|" ]]; then
                row+="$wall"
            elif [[ "$char" == " " ]]; then
                row+="$vide"
            elif [[ "$char" == "." ]]; then
                row+="$bonbon"
				((score_max+=10))
            elif [[ "$char" == "*" ]]; then
                row+="$bonus"
                coord_pac_gum+=($i,$coordyTemp);
            elif [[ "$char" == "C" ]]; then
                row+="$pacman"
                pacman_y=$coordyTemp
                pacman_x=$i
            elif [[ "$char" == "A" ]]; then
                row+="$vide"
                init_ghost_x=$i
                init_ghost_y=$coordyTemp
            fi
        done
        ((coordyTemp++))
        laby+=("$row")

    done < "$file"
}

# Affiche le labyrinthe avec des couleurs.
# lit le labyrinthe après traitement du fichier texte pour l'afficher et ajouter des couleurs au besoin
# Fait par Arthur
function print_laby(){
	local row_colored
	local row

	clear
	echo ""
    for row in "${laby[@]}"; do
		# syntaxe : "${ligne/caractere_a_remplacer/remplacement}"
		# \e[{style};{couleur}m		référence : https://gist.github.com/JBlond/2fea43a3049b38287e5e9cefc87b2124

		row_colored="${row//"$pacman"/"\e[1;33m$pacman\e[1;34m"}"
        row_colored="${row_colored//"$bonbon"/"\e[1;37m$bonbon\e[1;34m"}"
		row_colored="${row_colored//"$bonus"/"\e[1;37m$bonus\e[1;34m"}"
		if [[ $invincibility > 0 ]] ;then
        	row_colored="${row_colored//"$ghost"/"\e[1;36m$ghost\e[1;34m"}"
    	else
    		row_colored="${row_colored//"$ghost"/"\e[1;31m$ghost\e[1;34m"}"
    	fi
        echo -e "   \e[0;40m\e[1;34m$row_colored\e[0m"
    done
}

# Affiche l'écran de démarrage, attend un input du joueur autre que espace et entrer.
# Fait par Arthur
function displayStartScreen()
{	
	local input=""
	local i=0
	while [[ -z "$input" ]]; do
		clear
		echo -e "\e[1;33m
   ██████╗  █████╗  ██████╗███╗   ███╗ █████╗ ███╗   ██╗
   ██╔══██╗██╔══██╗██╔════╝████╗ ████║██╔══██╗████╗  ██║
   ██████╔╝███████║██║     ██╔████╔██║███████║██╔██╗ ██║
   ██╔═══╝ ██╔══██║██║     ██║╚██╔╝██║██╔══██║██║╚██╗██║
   ██║     ██║  ██║╚██████╗██║ ╚═╝ ██║██║  ██║██║ ╚████║
   ╚═╝     ╚═╝  ╚═╝ ╚═════╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝\e[0m
   \e[1;46m    QUESTE Arthur - DAVION Manon - KRZYSKOWIAK Noé   \e[0m
"
		if [[ $((i%2)) -eq 0 ]]; then
			echo -e "          Appuyer sur une touche pour commencer
\e[1;33m
		⠀⠀⣠⣴⣶⣶⣶⣦⣄
		 ⣾⣿⣿⣿⣿⣽⣿⣿⣷
		⢰⣿⣿⣿⣿⣿⣿⡛⠉⠁    \e[0m⣴⣶⡄\e[1;33m
		⠈⣿⣿⣿⣿⣿⣿⣿⣦⣀    \e[0m⠙⠛⠁\e[1;33m
		 ⠈⠻⢿⣿⣿⣿⡿⠟⠁\e[0m"
		else
			echo -e "
\e[1;33m
			 ⢀⣤⣶⣿⣿⣿⣶⣤⡀⠀
			⢀⣿⣿⣿⣿⣿⣯⣽⣿⣿⡄
			⠸⣿⣿⣿⣿⣿⣿⣿⣯⣛⠃
			⠀⢿⣿⣿⣿⣿⣿⣿⣿⡿⠀
			  ⠙⠛⠿⠿⠿⠟⠋   \e[0m"
		fi
		((i++))
		read -rsn1 -N1 -t 0.5 input
	done
}

# Fonction récursive permettant de choisir les cartes que l'utilsateur aurait créé ou les cartes déjà existantes.
# Fait par Noé
function print_laby5(){
    clear
    for((i=0; i<${#affichage4[@]}; i++)); do
        echo -e "${affichage4[$i]}"
    done
	local input
    read -rsn1 input
    case "$input" in
        $'1')
            ajout_utilisateur
            ;;
        $'2')
			print_laby4
            ;;
        *)
            echo -e "\e[0;31m   Ce n'est pas un chiffre valide\e[0m"
			sleep 0.2
            print_laby5
            ;;
        esac
}
# Fonction récursive permettant de choisir la manière de choisir sa façon de jouer.
# Fait par Noé
function print_laby4(){
    clear
    for((i=0; i<${#affichage3[@]}; i++)); do
        echo -e "${affichage3[$i]}"
    done
	local input
    read -rsn1 input
    case "$input" in
	    $'1')
            print_laby2
            print_laby3
            ;;
        $'2')
			random_difficulty
            random_map
            ;;
        $'3')
		    print_laby2
            random_map
            ;;
		$'4')
			random_difficulty
            print_laby3
            ;;
        $'5')
			print_laby5
            ;;
        *)
            echo -e "\e[0;31m   Ce n'est pas un chiffre valide\e[0m"
			sleep 0.2
            print_laby4
            ;;
        esac
}
# Fonction récursive permettant de choisir la carte.
# Fait par Noé
function print_laby3(){
    clear
    for((i=0; i<${#affichage2[@]}; i++)); do
        echo -e "${affichage2[$i]}"
    done
	local input
    read -rsn1 input
    case "$input" in
        $'1')
            file='map1.txt'
            lecture_map
            ;;
        $'2')
            file='map2.txt'
            lecture_map
            ;;
        $'3')
            file='map3.txt'
            ((nb_ghosts+=5))
            lecture_map
            ;;
        $'4')
            file='map4.txt'
			((nb_ghosts+=9))
            lecture_map
            ;;
        $'5')
			print_laby5
            ;;
        *)
            echo -e "\e[0;31m   Ce n'est pas un chiffre valide\e[0m"
			sleep 0.2
            print_laby3
            ;;
        esac
}
# Fonction récursive permettant de choisir la difficulté.
# Fait par Noé
function print_laby2(){
    clear
    for((i=0; i<${#affichage[@]}; i++)); do
        echo -e "${affichage[$i]}"
    done
	local input
    read -rsn1 input
    case "$input" in
        $'1')
			nb_ghosts=3
            ;;
        $'2')
			nb_ghosts=5
            ;;
        $'3')
			nb_ghosts=7
            ;;
        $'4')
			nb_ghosts=9
            ;;
        $'5')
			print_laby5
            ;;
        *)
            echo -e "\e[0;31m   Ce n'est pas un chiffre valide\e[0m"
			sleep 0.2
            print_laby2
            ;;
        esac
}
#fonction faite pare Noé
#fonction qui permet de choisir l'une des cartes au hasard
function random_map(){
	min=1
	max=4

	random_number=$((RANDOM % (max - min + 1) + min))
	case "$random_number" in
        $'1')
            file='map1.txt'
            lecture_map
            ;;
        $'2')
            file='map2.txt'
            lecture_map
            ;;
        $'3')
            file='map3.txt'
            ((nb_ghosts+=5))
            lecture_map
            ;;
        $'4')
            file='map4.txt'
			((nb_ghosts+=9))
            lecture_map
            ;;
        *)
            echo -e "\e[0;31m   Ce n'est pas un chiffre valide\e[0m"
			sleep 0.2
            print_laby5
            ;;
        esac

}
#fonction faite pare Noé
#fonction qui permet de choisir une difficulté au hasard
function random_difficulty(){
	min=1
	max=4

	random_number=$((RANDOM % (max - min + 1) + min))
	case "$random_number" in
        $'1')
			nb_ghosts=3
            ;;
        $'2')
			nb_ghosts=5
            ;;
        $'3')
			nb_ghosts=7
            ;;
        $'4')
			nb_ghosts=9
            ;;
        *)
            echo -e "\e[0;31m   Ce n'est pas un chiffre valide\e[0m"
			sleep 0.2
            print_laby5
            ;;
        esac

}
# Affiche le score.
# Fait par Manon
function print_score(){
	echo -e -n "   Score : \e[1;33m$score\e[0m"
}

# Affiche l'état du joueur
# Fait par Arthur
function print_invincibility(){
	local i=0
	local s=""

	for ((; i < 10; i++)); do
		if [ $i -lt $invincibility ]; then
			s+="■"
		else
			s+=" "
		fi
	done

	if [ $invincibility -gt 0 ]; then
		echo -e "  -  \e[0;32mInvulnérable\e[0m [$s]"
	else
		echo -e "  -  \e[0;31m  Vulnérable\e[0m [$s]"
	fi
}